<?php
	$Tumd['content'] = incPage('community/content');
<?php
    $Tumd['content'] = incPage('search/content');
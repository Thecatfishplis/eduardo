<?php

	if (!empty($_GET['id'])) {
       	$Tumd['profile']['id'] = secureEncode($_GET['id']);

       	# View account info
       	$sql_view_account = 'id,name,username,avatar_id,last_logged,last_update_info,profile_theme,active,xp';
        $sql_fetch_profile_row = getData($Tumd['profile']['id'], $sql_view_account);
			
		    # View user info
        $sql_query_user = $Tumdconnect->query("SELECT * FROM ".USERS." WHERE user_id = '{$sql_fetch_profile_row['id']}'");
        $sql_fetch_user_row = mysqli_fetch_array($sql_query_user);
        	
		if ($sql_fetch_profile_row == true) {

			$Tumd['profile']['data'] = $sql_fetch_profile_row;
			$Tumd['profile']['info'] = $sql_fetch_user_row;
      
			$Tumd['content'] = incPage('profile/content');

		} else { $Tumd['content'] = incPage('profile/error'); }
    } else { $Tumd['content'] = incPage('profile/error'); }
<?php
	if ($Tumd['access'] == true && $Tumd['data']['admin'] == true) {
		$Tumd['content'] = incPage('admin/content');
	}
<?php

	if ($access == true) {
		$Tumd['content'] = incPage('welcome/error');
	} else { 
		$Tumd['content'] = incPage('welcome/login');
	}
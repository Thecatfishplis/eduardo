<?php 

    if (!empty($_GET['id'])) {
        $Tumd['game']['id'] = secureEncode($_GET['id']);
    
        if (is_numeric($Tumd['game']['id']) && $Tumd['game']['id'] > 0) {
            $sql_query_game = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE game_id = '{$Tumd['game']['id']}'");
            
            if ($sql_query_game->num_rows == 1) {
                $sql_fetch_game_row = mysqli_fetch_array($sql_query_game);
                $Tumd['game']['rating'] = $sql_fetch_game_row['rating'];
        		$Tumd['game']['data'] = gameData($sql_fetch_game_row);

                if ($Tumd['access'] == true) {
                    $sql_verify_fav = $Tumdconnect->query("SELECT game_id FROM ".USER_GAME." WHERE user_id = '{$Tumd['data']['id']}' AND game_id='{$Tumd['game']['data']['game_id']}' AND type='favorite'") or die();
                    $Tumd['game']['favorite_status'] = ($sql_verify_fav->num_rows == 1) ? 'fav-added' : '';

                    $Tumdconnect->query("INSERT INTO ".USER_GAME." (user_id,game_id,date_added,type) VALUES ('{$Tumd['data']['id']}', '{$Tumd['game']['data']['game_id']}', '{$time}', 'played')") or die();
                }

                $Tumd['content'] = incPage('game/play');
            } else { $Tumd['content'] = incPage('game/error'); }
        } else { $Tumd['content'] = incPage('game/error'); }
    } else { $Tumd['content'] = incPage('game/error'); }
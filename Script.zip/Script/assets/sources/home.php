<?php
	$Tumd['content'] = incPage('home/content');
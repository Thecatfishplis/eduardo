<?php

	if ($Tumd['access'] == true) {
		setcookie('tumd_ac_u', 0, time()-60, '/');
		setcookie('tumd_ac_p', 0, time()-60, '/');

		header("Location: ".siteUrl()."/home");
	} else {
		header("Location: ".siteUrl()."/error");
	}
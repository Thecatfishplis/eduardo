<?php 
	/* Check install */
	$install_status = false;
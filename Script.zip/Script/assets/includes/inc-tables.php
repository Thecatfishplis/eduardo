<?php
/**
* Tumder Project - A platform for the fun
* @copyright (c) 2016 Loois Sndr. All rights reserved.
*
* @author Loois Sndr
* @since 2016
*/
define("SETTING", "tumd_setting");
define("GAMES", "tumd_games");
define("ACCOUNTS", "tumd_account");
define("USERS", "tumd_users");
define("MEDIA", "tumd_media");
define("LOGS", "tumd_userlogs");
define("USER_GAME", "tumd_favourites");
define("THEMES", "tumd_theme");
define("CATEGORIES", "tumd_categories");
define("ADS", "tumd_ads");
define("CATALOG", "tumd_feed_one");
define("REPORTS", "tumd_reports");
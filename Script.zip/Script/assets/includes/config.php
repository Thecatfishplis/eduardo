<?php
	
	/**
	* @global Parameters of database connection 
	*/

	// Host name
	$dbTumd['host'] = '';

	// Database name
	$dbTumd['name'] = '';

	// Host user name
	$dbTumd['user'] = '';

	// Host password
	$dbTumd['pass'] = '';

	/* Password encrypter *NOT REMOVE* */
	$encryption = "vmbtrvw95105595885345**#3738s**A";
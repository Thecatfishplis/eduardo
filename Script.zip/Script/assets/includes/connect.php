<?php
/**
* Tumder Project - A platform for the fun
* @copyright (c) 2016 Loois Sndr. All rights reserved.
*
* @author Loois Sndr
* @since 2016
*/

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname(dirname(dirname( __FILE__ ))) . '/' );
}

// Include config.php file
require_once( ABSPATH . 'assets/includes/config.php');

// Connect to SQL Server
$Tumdconnect = @new mysqli($dbTumd['host'], $dbTumd['user'], $dbTumd['pass'], $dbTumd['name']);

$time = ceil(time());
$date = date("j/m/y g:iA", $time);
$access = true;

require_once( ABSPATH . 'assets/includes/inc-install.php');
require_once( ABSPATH . 'assets/includes/core.php');
require_once( ABSPATH . 'assets/includes/inc-tables.php');
require_once( ABSPATH . 'assets/includes/inc-general.php');
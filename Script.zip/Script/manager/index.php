<?php
/**
* Tumder Project - A platform for the fun
* @copyright (c) 2016 Loois Sndr. All rights reserved.
*
* @author Loois Sndr
* @since 2016
*/

require_once( dirname(dirname( __FILE__ )) . '/td-load.php');
require_once( ABSPATH . 'td-indications.php');
define("ADMIN_ACCESS", true);

	if (($Tumd['access'] == true && $Tumd['data']['admin'] == true)) {
		header('Location: '.siteUrl().'/admin');
	} elseif (($Tumd['access'] == true && $Tumd['data']['admin'] == false)) {
		header('Location: '.siteUrl().'/error');
	} else { echo incPage('welcome/admin-login'); }

/*
* Close connection
*/
$Tumdconnect->close();
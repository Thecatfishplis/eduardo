<?php
/**
* Tumder Project - A platform for the fun
* @copyright (c) 2016 Loois Sndr. All rights reserved.
*
* @author Loois Sndr
* @since 2016
*/

require_once(dirname( __FILE__ ).'/td-load.php');
require_once(dirname( __FILE__ ).'/td-indications.php');
if ($install_status == false) {
	require_once(dirname( __FILE__ ).'/install/index.php');
	die();
}

	if (($Tumd['config']['setting']['site_maintenance'] == false) || ($Tumd['access'] == true && $Tumd['data']['admin'] == true)) {
		echo incPage('index');
	} else {
		echo incPage('welcome/maintenance');
	}

/* 
* Close connection 
*/
$Tumdconnect->close();
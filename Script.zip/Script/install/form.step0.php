<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<p>Welcome Tumder Platform. Before getting started, we need some information on the database. You will need to know the following items before proceeding.</p>
<ol>
	<li>Database name</li>
	<li>Database username</li>
	<li>Database password</li>
	<li>Database host</li>
</ol>
<p>We’re going to use this information to create the Database, <strong>Are you ready to start the installation?</strong></p>
<p class="br o-hidden">
	<a class="button button-green float-right" href="?step=1">Let's go</a>
</p>
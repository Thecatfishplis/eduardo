<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<form id="install-form-1" method="POST">
	<div class="messages"></div>
	<h2>Database Setup</h2>
	<table class="form-table">
		<tr>
			<th scope="row"><label for="db_name">Database Name</label></th>
			<td><input name="db_name" id="db_name" type="text"></td>
			<td>The name of the database you want to use with Tumder.</td>
		</tr>
		<tr>
			<th scope="row"><label for="db_user">Username</label></th>
			<td><input name="db_user" id="db_user" type="text"></td>
			<td>Your database username</td>
		</tr>
		<tr>
			<th scope="row"><label for="db_password">Password</label></th>
			<td><input name="db_password" id="db_password" type="text"></td>
			<td>Your database password.</td>
		</tr>
		<tr>
			<th scope="row"><label for="db_host">Database Host</label></th>
			<td><input name="db_host" id="db_host" type="text"></td>
			<td>Where your database is hosted.</td>
		</tr>
	</table>
	<p class="br">
		<button id="btn1" class="button button-blue" type="submit">Install</button>
	</p>
</form>
<?php
$step_process = array();
$step_process['step1'] = false;
$step_process['step2'] = false;
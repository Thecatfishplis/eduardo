<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<form id="install-form-2" method="POST">
	<div class="messages"></div>
	<h2>Account Setup</h2>
	<table class="form-table">
		<tr>
			<th scope="row"><label for="user">Admin User</label></th>
			<td><input name="user" id="user" type="text"></td>
			<td>Your username as administrator.</td>
		</tr>
		<tr>
			<th scope="row"><label for="password">Admin Password</label></th>
			<td><input name="password" id="password" type="text"></td>
			<td>Your password to access.</td>
		</tr>
		<tr>
			<th scope="row"><label for="pin">Admin PIN</label></th>
			<td><input name="pin" id="pin" type="text"></td>
			<td>An extra layer of security.</td>
		</tr>
		</table>
		<h2>Site Setup</h2>
		<table class="form-table">
		<tr>
			<th scope="row"><label for="site_name">Site Name</label></th>
			<td><input name="site_name" id="site_name" type="text"></td>
			<td>The name for your site</td>
		</tr>
		<tr>
			<th scope="row"><label for="site_url">Site Url</label></th>
			<td><input name="site_url" id="site_url" type="text"></td>
			<td>Site path <strong><i>e.g. http://site.com/tumder</i></strong></td>
		</tr>
	</table>
	<p class="br">
		<button id="btn1" class="button button-blue" type="submit">Submit</button>
	</p>
</form>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Tumder &rsaquo; Installer</title>
	<link rel="stylesheet" href="install/static/style.css">

	<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.min.js"></script>
	<script type="text/javascript" src="install/static/init.js"></script>
</head>
<body>
	<div class="logo">
		<a href="#"></a>
	</div>
	<div class="mainbox">
	<?php 
		switch ($_GET['step']) {
			case '0':
			default:
				include('form.step0.php');
			break;
			case '1':
				include('form.step1.php');
			break;
			case '2':
				include('form.step2.php');
			break;
		}
	?>
	</div>
</body>
</html>
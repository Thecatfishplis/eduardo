$(function () {
    $('#install-form-1').ajaxForm({
        url: 'install/install-request.php?o=db_install',
        type: 'POST',
        beforeSend: function() {
            $('#btn1').attr('disabled', true);
            messages_form = $('#install-form-1');
        },
        success: function(data) {
            if (data.status == 200) {
                document.location.href='?step=2';
            }
            else {
                $('.msg').remove();
                messages_form.find('.messages').after('<div class="msg msg-error hidden">'+ data.message_error +'</div>');
                messages_form.find('.msg').fadeIn('fast',function () {
                    $(this).fadeOut(4000, function() {
                        $(this).remove();
                    });
                });
            }
            $('#btn1').attr('disabled', false);
        }
    });

    $('#install-form-2').ajaxForm({
        url: 'install/install-request.php?o=db_account',
        type: 'POST',
        beforeSend: function() {
            $('#btn1').attr('disabled', true);
            messages_form = $('#install-form-2');
        },
        success: function(data) {
            if (data.status == 200) {
                document.location.href='manager/';
            }
            else {
                $('.msg').remove();
                messages_form.find('.messages').after('<div class="msg msg-error hidden">'+ data.message_error +'</div>');
                messages_form.find('.msg').fadeIn('fast',function () {
                    $(this).fadeOut(4000, function() {
                        $(this).remove();
                    });
                });
            }
            $('#btn1').attr('disabled', false);
        }
    });
});
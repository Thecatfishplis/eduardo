<?php 
/**
* Tumder Project - A platform for the fun
* @copyright (c) 2016 Loois Sndr. All rights reserved.
*
* @author Loois Sndr
* @since 2016
*/

error_reporting(0);
define("PILOT_GLOBAL", true);

if (!isset($_GET['p'])) {
    $_GET['p'] = 'home';
}

if (empty($_GET['p'])) {
    $_GET['p'] = 'error';
}

switch ($_GET['p']) {
    # Index page source
    case 'home':
    case 'index':
        include( dirname(__FILE__) . '/assets/sources/home.php');
    break;

    # Admin page source
    case 'admin':
        include( dirname(__FILE__) . '/assets/sources/admin-panel.php');
    break;

    # Game page source
    case 'play':
        include( dirname(__FILE__) . '/assets/sources/play.php');
    break;

    # Login page source
    case 'login':
        include( dirname(__FILE__) . '/assets/sources/login.php');
    break;

    # Register page source
    case 'signup':
        include( dirname(__FILE__) . '/assets/sources/register.php');
    break;

    # Settings page source
    case 'setting':
        include( dirname(__FILE__) . '/assets/sources/setting.php');
    break;

    # Profile page source
    case 'profile':
        include( dirname(__FILE__) . '/assets/sources/profile.php');
    break;

    # Logout
    case 'logout':
        include( dirname(__FILE__) . '/assets/sources/logout.php');
    break;

    # Community page source
    case 'community':
        include( dirname(__FILE__) . '/assets/sources/community.php');
    break;

    # Categories page source
    case 'categories':
        include( dirname(__FILE__) . '/assets/sources/categories.php');
    break;

    case 'search':
        include( dirname(__FILE__) . '/assets/sources/search.php');
    break;
}

# If no sources found
if (empty($Tumd['content'])) {
    $Tumd['content'] = incPage('welcome/error');
}
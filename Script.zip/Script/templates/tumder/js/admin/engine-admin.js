$(function () {
    
    $(document).ready(function(){
        $(document).on('click', '.game_type-import', function(){
            var __rEi = $(this);
            __addgame_showImport(__rEi);
        });

        function __addgame_showImport(game_type_import) {
            var __It1 = $('#game_import0');
            var __It0 = $('#game_import1');
            var __ValIt = $('.game_type-import--val');

            if (game_type_import.hasClass('i-t-1')) {
                __It0.show();
                __It1.hide();
                __ValIt.attr('value', 1);
            } else if(game_type_import.hasClass('i-t-0')) {
                __It1.show();
                __It0.hide();
                __ValIt.attr('value', 0);
            }
            
        }

        $(document).on('click', '.game_state-E', function(){
            var __rHs = $(this);
            __addgame_State(__rHs);
        });

        function __addgame_State(__sId) {
            var __Vals1 = $('.game_published--val');
            var __Vals2 = $('.game_featured--val');

            if (__sId.hasClass('s-t-P')) {
                if (__Vals1.val() == 1) {
                    __Vals1.attr('value', 0);
                } else {
                    __Vals1.attr('value', 1);
                }
            } else if (__sId.hasClass('s-t-F')) {
                if (__Vals2.val() == 1) {
                    __Vals2.attr('value', 0);
                } else {
                    __Vals2.attr('value', 1);
                }
            }
        }

        $(document).on('click', '.report-btn-action', function(){
            var __rHs = $(this);
            __rp_actEx(__rHs);
        });

        function __rp_actEx($bThis) {
            var _actTy = $bThis.attr('data-rp-action');
            var _rp_Inf = $bThis.attr('data-rp-id');
            if (_actTy == 1) {
                var _rp_Usr = $bThis.attr('data-user');
                $.ajax({
                    url: Ajaxrequest() + '?t=admin&a=act_report',
                    type: 'POST',
                    data: "uid=" + _rp_Usr + "&rp_id=" + _rp_Inf,
                    success: function() {
                        $('.report-r' + _rp_Inf).slideToggle(200, function() {
                            $(this).remove();
                        });
                    }
                });
            } else if (_actTy == 2) {
                $.ajax({
                    url: Ajaxrequest() + '?t=admin&a=act_report',
                    type: 'POST',
                    data: "rp_id=" + _rp_Inf,
                    success: function() {
                        $('.report-r' + _rp_Inf).slideToggle(200, function() {
                            $(this).remove();
                        });
                    }
                });
            }
        }
    });

    /* ADD GAME */
    var addgame_bar = $('.addgame_bar');
    var addprogress = $('.addgame_progress');

    $('#addgame-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=addgame',
        type: 'POST',
        beforeSend: function() {
            form_h = $('.addgame-header');
            addgame_btn = form_h.find('#addgame-btn');
            addgame_btn.attr('disabled', true);
            var ag_pV = '0%';
            addgame_bar.width(ag_pV)
        }, 
        uploadProgress: function(event, position, total, percentComplete) {
            addprogress.show()
            var ag_pV = percentComplete + '%';
            addgame_bar.width(ag_pV)
            //console.log(ag_pV, position, total);
        }, 
        success: function(data) {
            if (data.status == 200) {
                addprogress.hide()
                addgame_bar.width('0%')
                document.getElementById('addgame-form').reset();
                Toast.success(data.success_message);
            }
            else {
                addprogress.hide()
                addgame_bar.width('0%')
                Toast.error(data.error_message);
            }
            addgame_btn.attr('disabled', false);
        }
    });


    /* EDIT GAME */
    var editgame_bar = $('.editgame_bar');

    $('#editgame-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=editgame',
        type: 'POST',
        beforeSend: function() {
            form_h = $('.editgame-header');
            addgame_btn = form_h.find('#addgame-btn');
            addgame_btn.attr('disabled', true);
            var eg_pV = '0%';
            editgame_bar.width(eg_pV)
            eg_m_uploadInput = $('#_-2m-f');
            eg_f_uploadInput = $('#_-3f-f');
        }, 
        uploadProgress: function(event, position, total, percentComplete) {
            var eg_pV = percentComplete + '%';
            editgame_bar.width(eg_pV)
            //console.log(eg_pV, position, total);
        }, 
        success: function(data) {
            if (data.status == 200) {
                $('#editgame_image').attr('src', data.game_img);
                $('#editgame_name').text(data.game_name);
                eg_m_uploadInput.replaceWith(eg_m_uploadInput.val('').clone(true));
                eg_f_uploadInput.replaceWith(eg_f_uploadInput.val('').clone(true));

                Toast.success(data.success_message);
            }
            else {
                Toast.error(data.error_message);
            }
            addgame_btn.attr('disabled', false);
        }
    });

    /* MANAGE GAMES */
    $(document).ready(function(){
        $(document).on('click', '#mg--published', function(){
            var _mg_eXid = $(this).attr('data-game');
            var _mg_eXpb = $('.mg_p-' + _mg_eXid).attr('data-pb');
            __ajaxManageStatusGame(_mg_eXid, _mg_eXpb, 1);
        });

        $(document).on('click', '#mg--featured', function(){
            var _mg_eXid = $(this).attr('data-game');
            var _mg_eXpb = $('.mg_f-' + _mg_eXid).attr('data-ft');
            __ajaxManageStatusGame(_mg_eXid, _mg_eXpb, 2);
        });

        $(document).on('click', '#mg--delete', function(){
            var _mg_eXid = $(this).attr('data-game');
            __ajaxManageStatusGame(_mg_eXid, 0, 3);
        });

        function __ajaxManageStatusGame(gid, ss, tp) {
            if (tp == 1) {
                $.ajax({
                    url: Ajaxrequest() + '?t=admin&a=mg_published',
                    type: 'POST',
                    data: "gid=" + gid,
                    success: function() {
                        var _pd4 = $('.mg_p-' + gid);
                        if (ss == 1) {
                            _pd4.removeClass('pub-active');
                            _pd4.attr('data-pb', '0');
                        } else {
                            _pd4.addClass('pub-active');
                            _pd4.attr('data-pb', '1');
                        }
                    }
                });
            } else if (tp == 2) {
                $.ajax({
                    url: Ajaxrequest() + '?t=admin&a=mg_featured',
                    type: 'POST',
                    data: "gid=" + gid,
                    success: function() {
                        var _ft0 = $('.mg_f-' + gid);
                        if (ss == 1) {
                            _ft0.removeClass('feat-active');
                            _ft0.attr('data-ft', '0');
                        } else {
                            _ft0.addClass('feat-active');
                            _ft0.attr('data-ft', '1');
                        }
                    }
                });
            } else if (tp == 3) {
                $.ajax({
                    url: Ajaxrequest() + '?t=admin&a=mg_delete',
                    type: 'POST',
                    data: "gid=" + gid,
                    success: function() {
                        var _dlt9 = $('.__mg-' + gid);
                        _dlt9.slideToggle(200, function() {
                            $(this).remove();
                        });
                    }
                });
            }
        }
    });

    /* MANAGE CATEGORIES */

    $('#addcategory-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=addcategory',
        type: 'POST', 
        success: function(data) {
            if (data.status == 200) {
                Toast.success(data.success_message);
            }
            else {
                Toast.error(data.error_message);
            }
        }
    });

    $('#editcategory-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=editcategory',
        type: 'POST', 
        success: function(data) {
            if (data.status == 200) {
                Toast.success(data.success_message);
            }
            else {
                Toast.error(data.error_message);
            }
        }
    });

    $(document).ready(function(){
        $(document).on('click', '#mc--delete', function(){
            var _mc_eXcid = $(this).attr('data-category');
            __dltCtgr7(_mc_eXcid);
        });

        function __dltCtgr7(cid) {
            $.ajax({
                url: Ajaxrequest() + '?t=admin&a=mc_delete',
                type: 'POST',
                data: "cid=" + cid,
                success: function() {
                    var _cdlt3 = $('.__mc-' + cid);
                    _cdlt3.slideToggle(200, function() {
                        $(this).remove();
                    });
                }
            });
        }
    });

    /* MANAGE SETTING */
    $('#adminsetting-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=setting',
        type: 'POST',
        success: function(data) {
            if (data.status == 200) {
                Toast.success(data.success_message);
            }
            else {
                Toast.error(data.error_message);
            }
        }
    });

    /* MANAGE USERS */
    $('#edituser-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=edituser',
        type: 'POST',
        success: function(data) {
            if (data.status == 200) {
                Toast.success(data.success_message);
            } else {
                Toast.error(data.error_message);
            }
        }
    });

    /* SEARCH USERS TO EDIT */
    $('#search-useredit-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=searchUserEdit',
        type: 'POST',
        success: function(data) {
            if (data.status == 200) {
                window.location = data.redirect_url;
            } else {
                Toast.error(data.error_message);
            }
        }, 
        error: function() {
            console.log('Connection failed!');
        }
    });

    /* MANAGE ADS AREA */
    $('#adsArea-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin&a=manageAdsArea',
        type: 'POST',
        success: function(data) {
            if (data.status == 200) {
                Toast.success(data.success_message);
            }
        }
    });


    /*******************\
       MANAGE FEED DATA  
    \*******************/

    $(document).ready(function(){
        $(document).on('click', '#getGameData', function(){
            var __rEi = $(this);
            __extr_FeedGD_pr(__rEi);
        });

        function __extr_FeedGD_pr($feed_type) {
            var feed_type = $feed_type.attr('data-feed');
            var feed_mode = $feed_type.attr('data-feed-alert');

            $.ajax({
                url: Ajaxrequest() + '?t=admin&a=game_feed&p=getfeed_type_' + feed_type,
                type: 'POST',
                beforeSend: function() {
                    image_loader = $('.tumd-loader');
                    image_loader.show();
                    $feed_type.attr('disabled', true);
                },
                success: function(data) {
                    image_loader.hide();
                    $feed_type.attr('disabled', false);
                    if (feed_mode == 'true' | feed_mode) {
                        Toast.success(data.success_message);
                    } else if(feed_mode == 'false' | !feed_mode) {
                        startLoadbar();
                        Tumder_ajaxLoad(data.redirect_url);
                        stopLoadbar();
                    }
                }, 
                error: function() {
                    image_loader.hide();
                    $feed_type.attr('disabled', false);
                    console.log('Connection failed!');
                }
            });
        }

        // INSTALL GAME
        $(document).on('click', '#install-game', function(){
            var __rEi = $(this);
            var __gID = $(this).attr('data-gid');
            __installGame(__rEi, __gID);
        });

        function __installGame($_cr4, gid) {
            $.ajax({
                url: Ajaxrequest() + '?t=admin&a=game_install',
                type: 'POST',
                data: "c_id=" + gid,
                success: function(data) {
                    $_cr4.attr('disabled', true);
                    $_cr4.removeClass('color-b');
                    $_cr4.addClass('color-a');
                    $_cr4.removeClass('fa-cloud-download');
                    $_cr4.addClass('fa-check-circle');
                }, 
                error: function() {
                    image_loader.hide();
                    $_cr4.attr('disabled', false);
                    console.log('Connection failed!');
                }
            });
        }

        // DELETE GAME FROM CATALOG
        $(document).on('click', '#delete-catalog-item', function(){
            var __rEdl = $(this);
            var __gID = $(this).attr('data-gid');
            __dlGame(__rEdl, __gID);
        });

        function __dlGame($_cr5, gid) {
            $.ajax({
                url: Ajaxrequest() + '?t=admin&a=game_delete',
                type: 'POST',
                data: "c_id=" + gid,
                success: function() {
                    var $_cr5 = $('._dl-g' + gid);
                    $_cr5.slideToggle(200, function() {
                        $(this).remove();
                    });
                }
            });
        }

    });
});
<?php if ( defined("PILOT_GLOBAL") != true) { die(); }?>
<div class="page-wrapper">
<div class="tumd-main pull-right span79">
	<?php if (!isset($_GET['section']) or $_GET['section'] == "global") {
		echo incPage('admin/stats');
	} elseif (isset($_GET['section']) && $_GET['section'] == "addgame") {
		echo incPage('admin/add-game');
	} elseif (isset($_GET['section']) && $_GET['section'] == "setting") {
		echo incPage('admin/setting');
	} elseif (isset($_GET['section']) && $_GET['section'] == "games") {
		echo incPage('admin/games');
	} elseif (isset($_GET['section']) && $_GET['section'] == "categories") {
		echo incPage('admin/categories');
	} elseif (isset($_GET['section']) && $_GET['section'] == "users") {
		echo incPage('admin/users');
	} elseif (isset($_GET['section']) && $_GET['section'] == "ads") {
		echo incPage('admin/ads');
	} elseif (isset($_GET['section']) && $_GET['section'] == "catalog") {
		echo incPage('admin/games-catalog');
	} elseif (isset($_GET['section']) && $_GET['section'] == "reports") {
		echo incPage('admin/reports');
	} else {echo incPage('welcome/error-section'); } ?>
</div>

	<?=incPage('admin/nav-menu')?>
</div>
<?php if ( defined("PILOT_GLOBAL") != true) { die(); } ?>
<div class="tumd-main-headself">
	<i class="fa fa-plus"></i>
</div>
<div class="general-box _y9 _0e4">
	<form id="addgame-form" enctype="multipart/form-data">
		<div class="g-d5 addgame-dashboard">
			<div class="r05-t _b-r _5e4">
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/name.png">
					<input placeholder="<?=$lang['game_name']?>" class="_text-input _tr5" type="text" name="game_name">
				</div>
				<div>
					<textarea placeholder="<?=$lang['game_description']?>" class="_text-input _tr5" name="game_description"></textarea>
				</div>
				<div>
					<textarea placeholder="<?=$lang['game_instructions']?>" class="_text-input _tr5" name="game_instructions"></textarea>
				</div>
				<div>
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/category.png" width="20">
					<span class="_tr5"><?=$lang['game_category']?></span>
					<select name="game_category" class="_p4s8">
						<?php 
							$addgame_category = $Tumdconnect->query("SELECT * FROM ".CATEGORIES." WHERE id!=0");
							while ($select_category = mysqli_fetch_array($addgame_category)) {
								echo '<option value="'.$select_category['id'].'">'.$select_category['name'].'</option>';
							}
						?>
					</select>
				</div>
			</div>
			<div class="r05-t _5e4">
				<div>
					<div class="_cE3-xf">
						<button type="button" class="game_type-import i-t-0 fa fa-pencil icon-22"></button>
						<button type="button" class="game_type-import i-t-1 fa fa-cloud-upload icon-22"></button>
					</div>
		
					<div id="game_import0">
						<div class="_input-box">
							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/image.png">
							<input placeholder="<?=$lang['game_image']?>" class="_text-input _tr5" type="text" name="game_image">
						</div>
						<div class="_input-box">
							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file.png">
							<input placeholder="<?=$lang['game_file']?>" class="_text-input _tr5" type="text" name="game_file">
						</div>
					</div>
					<div id="game_import1" class="game_import-filepanel r-r3 _10e4 _a0">
						<div>
							<label>
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/image.png" width="20">
								<span class="_tr5"><?=$lang['game_image']?></span>
								<input type="file" name="__game_image">
							</label>
						</div>
						<div>
							<label>
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file.png" width="20">
								<span class="_tr5"><?=$lang['game_file']?></span>
								<input type="file" name="__game_file">
							</label>
						</div>
						<div class="addgame_progress progress _a0">
        					<div class="addgame_bar progress-bar progress-bar-success"></div>
    					</div>
    				</div>
    				<div class="_tr5 _bold"><?=$lang['game_size']?></div>
    				<div class="_cE3-xf">
    					<div class="_cE3-x7">
    						<div class="_input-box">
    							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/width.png">
								<input placeholder="<?=$lang['game_width']?>" class="_text-input _tr5" type="number" name="game_width">
							</div>
						</div>
						<div class="_cE3-x7">
							<div class="_input-box">
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/height.png">
								<input placeholder="<?=$lang['game_height']?>" class="_text-input _tr5" type="number" name="game_height">
							</div>
						</div>
					</div>
    				<div>
    					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file_type.png" width="20">
    					<select name="game_file_type" class="_p4s8">
							<option value="swf"><?=$lang['game_type_swf']?></option>
							<option value="other"><?=$lang['game_type_html']?></option>
						</select>
    				</div>
				</div>
				<input type="hidden" class="game_published--val" name="game_published" value="0">
				<input type="hidden" class="game_featured--val" name="game_featured" value="0">
				<input type="hidden" class="game_type-import--val" name="game_import" value="0">
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<label class="_p4s8 lb-cstm"><input type="checkbox" id="_-p" class="game_state-E s-t-P"><?=$lang['game_published']?></label>
			<label class="_p4s8 lb-cstm"><input type="checkbox" id="_-f" class="game_state-E s-t-F"><?=$lang['game_featured']?></label>
			<label>
				<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/rating.png" width="20">
				<select name="game_rating" class="_p4s8">
					<option value="0">0</option>
					<option value="0.5">0.5</option>
					<option value="1">1</option>
					<option value="1.5">1.5</option>
					<option value="2">2</option>
					<option value="2.5">2.5</option>
					<option value="3">3</option>
					<option value="3.5">3.5</option>
					<option value="4">4</option>
					<option value="4.5">4.5</option>
					<option value="5">5</option>
				</select>
			</label>
			<button type="submit" id="addgame-btn" class="btn-p btn-p1">
				<i class="fa fa-plus icon-18 icon-middle"></i>
				<?=$lang['game_add']?>
			</button>
		</div>
	</form>
</div>
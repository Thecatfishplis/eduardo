<?php if ( defined("PILOT_GLOBAL") != true) { die(); } ?>
<div class="_header-section admin-hh-style">
	<span class="_content-title _content-color-a"><img class="img-50" src="<?=$Tumd['theme_url']?>/image/icon-color/shield.png"> <?=$lang['administration']?></span>
</div>
<div class="stats-box-container _y5">
	<div class="stats-box" title="<?=$lang['games_installed']?>">
		<div class="stats-icon-box stats-bg-one"><i class="fa fa-gamepad"></i></div>
		<div class="stats-info stats-color-one ellipsis"><?=getStats('games')?></div>	
	</div>
	<div class="stats-box" title="<?=$lang['users_registered']?>">
		<div class="stats-icon-box stats-bg-two"><i class="fa fa-user"></i></div>
		<div class="stats-info stats-color-two ellipsis"><?=getStats('users')?></div>	
	</div>
	<div class="stats-box" title="<?=$lang['categories_registered']?>">
		<div class="stats-icon-box stats-bg-three"><i class="fa fa-bookmark"></i></div>
		<div class="stats-info stats-color-three ellipsis"><?=getStats('categories')?></div>	
	</div>
	<div class="stats-box" title="<?=$lang['games_in_catalog']?>">
		<div class="stats-icon-box stats-bg-four"><i class="fa fa-book"></i></div>
		<div class="stats-info stats-color-four ellipsis"><?=getStats('catalog_games')?></div>	
	</div>
</div>

<div class="g-d5 general-box _0e4 _y9 r-r3 users-status-dashboard">
	<div class="r05-t _b-r _a-j last-users-container">
		<div class="_5e4 last-users-title last-users-bc-1 _tr5"><i class="fa fa-user-plus icon-18 icon-middle"></i> <?=$lang['last_users_registered']?></div>
<?php
	$getLastUser_registered = lastUser('registered', 4);
	foreach ($getLastUser_registered as $last_user) {
		$getInfo = getInfo($last_user->id);
		$last_user->avatar = getAvatar($last_user->avatar_id, $getInfo->gender, 'thumb');
?>
		<div class="_b-t _5e4">
			<img class="img-circle _a6" src="<?=$last_user->avatar?>" width="40">
			<div class="_a6 last-users-name"><?=$last_user->name?></div>
			<button class="pull-right btn-edit-user" data-href="<?=siteUrl()?>/admin/users/edit/<?=$last_user->username?>">
				<i class="fa fa-wrench icon-middle icon-18"></i>
			</button>
		</div>
<?php } ?>
	</div>

	<div class="r05-t _a-j last-users-container">
		<div class="_5e4 last-users-title last-users-bc-2 _tr5"><i class="fa fa-sign-in icon-18 icon-middle"></i> <?=$lang['last_users_logged']?></div>
<?php
	$getLastUser_logged = lastUser('login', 4);
	foreach ($getLastUser_logged as $last_user) {
		$getInfo = getInfo($last_user->id);
		$last_user->avatar = getAvatar($last_user->avatar_id, $getInfo->gender, 'thumb');
?>
		<div class="_b-t _5e4">
			<img class="img-circle _a6" src="<?=$last_user->avatar?>" width="40">
			<div class="_a6 last-users-name"><?=$last_user->name?></div>
			<button class="pull-right btn-edit-user" data-href="<?=siteUrl()?>/admin/users/edit/<?=$last_user->username?>">
				<i class="fa fa-wrench icon-middle icon-18"></i>
			</button>
		</div>
<?php } ?>
	</div>
</div>
<?php if ( defined("PILOT_GLOBAL") != true) { die(); }
	$query_reports = $Tumdconnect->query("SELECT * FROM ".REPORTS." WHERE report_id!=0");
	if($query_reports->num_rows > 0) {
?>
<ul class="_rep-container">
	<?php
		while ($report = $query_reports->fetch_object()) {
		$datauser = getData($report->user_id, 'id,name,username');
		$user_id = ($datauser == true) ? $datauser['id'] : 0;
		$user_name = ($datauser == true) ? '<a href="'.siteUrl().'/profile/'.$datauser['username'].'">'.$datauser['name'].'</a>':'Anom';
	?>
	<li class="report-r<?=$report->report_id?> _rep-item">
		<div class="g-d5 _j4">
			<button class="report-btn-action ot fa fa-thumbs-up icon-18 ic-act ic-2" data-rp-action="1" data-rp-id="<?=$report->report_id?>" data-user="<?=$user_id?>"></button>
			<button class="report-btn-action ot fa fa-thumbs-down icon-18 ic-act ic-3" data-rp-action="2" data-rp-id="<?=$report->report_id?>"></button>
			<button class="ot fa fa-pencil icon-18 ic-act ic-1" data-href="<?=siteUrl()?>/admin/games/edit/<?=$report->id_reported?>"></button>
		</div>
		<div><?=$user_name?></div>
		<textarea class="b-input scroll-custom" readonly="readonly"><?=$report->report_info?></textarea>
	</li>
	<?php } ?>
</ul>
<?php } else { ?>
<div class="_a-c _e55">
	<div>
		<img src="<?=$Tumd['theme_url']?>/image/icon-color/megaphone.png">
	</div>
	<h3 class="color-grey"><?=$lang['no_reports']?></h3>
</div>
<?php } ?>
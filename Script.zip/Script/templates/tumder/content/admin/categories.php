<?php if ( defined("PILOT_GLOBAL") != true) { die(); }?>
<div class="tumd-main-headself">
	<i class="fa fa-bookmark"></i>
</div>
<?php if (!isset($_GET['action']) OR $_GET['action'] == "view") { ?>
<div class="general-box box-m _0e4">
	<div class="header-box">
		<button class="btn-p btn-w" data-href="<?=siteUrl()?>/admin/categories/add"><i class="fa fa-plus icon-middle icon-18 color-grey"></i> <?=$lang['add_new_category']?></button>
	</div>
	<ul class="categories-list scroll-custom">
	<?php
		$sql_global_categories = $Tumdconnect->query("SELECT * FROM ".CATEGORIES." WHERE id!=0");
		while ($global_categories = mysqli_fetch_array($sql_global_categories)) {
	?>
		<li class="__mc-<?=$global_categories['id']?> g-d5 _j4 categories-item">
			<div class="_category-name color-grey"><?=$global_categories['name']?></div>
			<div>
				<button data-href="<?=siteUrl()?>/admin/categories/edit/<?=$global_categories['id']?>" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
				<?php if ($global_categories['id'] != 1) { ?>
				<button id="mc--delete" class="mc_d-<?=$global_categories['id']?> btn-p btn-small btn-p3 fa fa-trash" data-category="<?=$global_categories['id']?>"></button>
				<?php } ?>
			</div>
		</li>
	<?php } ?>
	</ul>
</div>
<?php } elseif (isset($_GET['action']) && $_GET['action'] == "add") { ?>
<div class="general-box box-m _0e4">
	<div class="header-box">
		<i class="fa fa-plus color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="addcategory-form" enctype="multipart/form-data" method="POST" autocomplete="off">
			<div class="vByg5">
				<input type="text" name="ac_name" placeholder="<?=$lang['category_name']?>">
			</div>
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-plus icon-middle"></i>
				<?=$lang['add']?>
			</button>
		</form>
	</div>
</div>
<?php } elseif (isset($_GET['action']) && $_GET['action'] == "edit" && !empty($_GET['cid'])) {
	$category_id = secureEncode($_GET['cid']);
	$sql_select_editcategory = $Tumdconnect->query("SELECT * FROM ".CATEGORIES." WHERE id='{$category_id}'");
	if ($sql_select_editcategory->num_rows == 1) {
		$edit_category = mysqli_fetch_array($sql_select_editcategory);
?>
<div class="general-box box-m _0e4">
	<div class="header-box">
		<i class="fa fa-pencil color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="editcategory-form" enctype="multipart/form-data" method="POST">
			<div class="vByg5">
				<input type="text" name="ec_name" value="<?=$edit_category['name']?>">
				<input type="hidden" name="ec_id" value="<?=$category_id?>">
			</div>
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				<?=$lang['save']?>
			</button>
		</form>
	</div>
</div>
<?php } else { 
	echo incPage('welcome/error-section'); 
} } else { 
	echo incPage('welcome/error-section'); 
} ?> 
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }
	if (isset($_GET['section'])) { $_data = $_GET['section']; } else { $_data = 'global'; }
?>
<div class="tumd-nav pull-left span20">
	<div class="tumd-nav-headself">
		<?=$lang['administration']?>
	</div>
	<ul>
		<li class="_4lf <?=listMenu($_data, 'global')?>">
			<a href="<?=siteUrl()?>/admin" class="spf-link _p"></a>
			<i class="fa fa-globe icon-middle"></i> <?=$lang['menu_global']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'addgame')?>">
			<a href="<?=siteUrl()?>/admin/addgame" class="spf-link _p"></a>
			<i class="fa fa-plus icon-middle"></i> <?=$lang['menu_addgame']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'setting')?>">
			<a href="<?=siteUrl()?>/admin/setting" class="spf-link _p"></a>
			<i class="fa fa-cog icon-middle"></i> <?=$lang['menu_setting']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'games')?>">
			<a href="<?=siteUrl()?>/admin/games" class="spf-link _p"></a>
			<i class="fa fa-gamepad icon-middle"></i> <?=$lang['menu_games']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'categories')?>">
			<a href="<?=siteUrl()?>/admin/categories" class="spf-link _p"></a>
			<i class="fa fa-bookmark icon-middle"></i> <?=$lang['menu_categories']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'users')?>">
			<a href="<?=siteUrl()?>/admin/users" class="spf-link _p"></a>
			<i class="fa fa-user icon-middle"></i> <?=$lang['menu_edit_users']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'ads')?>">
			<a href="<?=siteUrl()?>/admin/ads" class="spf-link _p"></a>
			<i class="fa fa-flag-o icon-middle"></i> <?=$lang['menu_ads']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'catalog')?>">
			<a href="<?=siteUrl()?>/admin/catalog" class="spf-link _p"></a>
			<i class="fa fa-book icon-middle"></i> <?=$lang['menu_games_catalog']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'reports')?>">
			<a href="<?=siteUrl()?>/admin/reports" class="spf-link _p"></a>
			<i class="fa fa-bullhorn icon-middle"></i> <?=$lang['menu_reports']?> 
			<?=(reportsStatus()) ? '<span class="notif-menu">'.reportsStatus().'</span>' : ''?>
		</li>
	</ul>
</div>
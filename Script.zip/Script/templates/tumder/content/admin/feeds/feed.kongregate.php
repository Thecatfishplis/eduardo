<?php if ( defined("PILOT_GLOBAL") != true) { die(); } ?>
<div class="section-box feed-one _a-c">
	<img width="150" src="<?=siteUrl()?>/static/libs/images/feed-logos/kongregate.png">
</div>

<?php
	$query_catalog = $Tumdconnect->query("SELECT * FROM ".CATALOG." WHERE pilot='feed_one'");
	if($query_catalog->num_rows == true) {
?>
<ul class="catalog-box scroll-custom">
<?php
	while ($catalog_item = mysqli_fetch_object($query_catalog)) {
		$query_game_v_install = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE catalog_id='{$catalog_item->gid}'");
		$g_verInstall = ($query_game_v_install->num_rows == 0) ? 
			'<button id="install-game" data-gid="'.$catalog_item->id.'" class="ic-act ot color-b fa fa-cloud-download icon-18 icon-middle"></button>' : 
			'<i class="fa fa-check-circle icon-18 color-a icon-middle"></i>';
?>
	<li class="catalog-item __game-actions _pr _a-c _dl-g<?=$catalog_item->id?>" title="<?=$catalog_item->name?>">
		<img class="item-picture" src="<?=$catalog_item->image?>">
		<div class="_cR3-p ellipsis"><?=$catalog_item->name?></div>
		<div class="manage--p _p">
			<?=$g_verInstall?>
			<button id="delete-catalog-item" data-gid="<?=$catalog_item->id?>" class="ic-act ot color-c fa fa-trash icon-18 icon-middle"></button>		
		</div>
	</li>
<?php } ?>
<ul>
<?php } else { ?>
	<div class="_a-c _m-box-error">
		<span>
			<img src="<?=$Tumd['theme_url']?>/image/icon-color/catalog.png">
			<p><?=$lang['catalog_empty']?></p>
		</span>
	</div>
<?php } ?>
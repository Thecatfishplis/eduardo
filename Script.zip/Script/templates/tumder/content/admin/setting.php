<?php if ( defined("PILOT_GLOBAL") != true) { die(); } ?>
<div class="tumd-main-headself">
	<i class="fa fa-cog"></i>
</div>
<div class="general-box _y9 _0e4">
	<form id="adminsetting-form" enctype="multipart/form-data" method="POST" autocomplete="off">
		<div class="g-d5">
			<!--# INFO SECTION #-->
			<div class="r05-t _b-r _5e4">
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_name']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/name.png">
					<input class="_text-input" type="text" name="ss_sitename" value="<?=$Tumd['config']['setting']['site_name']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_desc']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/description.png">
					<input class="_text-input" type="text" name="ss_sitedescription" value="<?=$Tumd['config']['setting']['site_description']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_keywords']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/tag.png">
					<input class="_text-input" type="text" name="ss_sitekeywords" value="<?=$Tumd['config']['setting']['site_keywords']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_url']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/url.png">
					<input class="_text-input" type="text" name="ss_siteurl" value="<?=$Tumd['config']['setting']['site_url']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_admin_pin']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/pincode.png">
					<input class="_text-input" type="text" name="ss_pin" value="<?=$Tumd['config']['setting']['admin_pin']?>">
				</div>
			</div>
			<!--# XP AND LIMIT SECTION #-->
			<div class="r05-t _5e4">
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_xp_play']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/xp.png">
					<input class="_text-input" type="number" name="ss_xp_play" value="<?=$Tumd['config']['setting']['xp_play']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_xp_report']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/xp.png">
					<input class="_text-input" type="number" name="ss_xp_report" value="<?=$Tumd['config']['setting']['xp_report']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_xp_register']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/xp.png">
					<input class="_text-input" type="number" name="ss_xp_register" value="<?=$Tumd['config']['setting']['xp_register']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_games_featured']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/heart.png">
					<input class="_text-input" type="number" name="ss_featured_game_limit" value="<?=$Tumd['config']['setting']['featured_game_limit']?>">
				</div>
				<span class="_tr5 _yt5 color-grey"><?=$lang['site_games_mp']?></span>
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/crown.png">
					<input class="_text-input" type="number" name="ss_mp_game_limit" value="<?=$Tumd['config']['setting']['mp_game_limit']?>">
				</div>
			</div>
		</div>

		<div class="g-d5">
			<!--# GENERAL SECTION #-->
			<div class="r05-t _b-t _b-r _5e4">
				<div class="_a6">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/theme.png" width="20">
					<span class="_tr5 color-grey"><?=$lang['site_template']?></span>
					<select name="ss_sitetheme" class="_p4s8">
						<?php
							$THEME_dir = opendir('templates/');
							$THEME_dr_array = array();
							while (false !== ($file = readdir($THEME_dir))) {
								$THEME_dr_array[] = $file;
							}
							closedir($THEME_dir);

							foreach($THEME_dr_array as $file) {
								if ($file != "." && $file != ".." && $file != "Thumbs.db" && $file != ".DS_Store" && $file != "images") {
									if ($Tumd['config']['setting']['site_theme'] == $file) {
										echo '<option value="'.$file.'" selected>'.$file.'</option>';
									} else {
										echo '<option value="'.$file.'">'.$file.'</option>';
									}
								}
							}
						?>
					</select>
				</div>
				<div class="_a6 pull-right">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/lang.png" width="20">
					<span class="_tr5 color-grey"><?=$lang['site_lang']?></span>
					<select name="ss_sitelang" class="_p4s8">
						<?php
							$LANG_dir = opendir('assets/language/');
							$LANG_dr_array = array();
							while (false !== ($file = readdir($LANG_dir))) {
								$LANG_dr_array[] = $file;
							}
							closedir($LANG_dir);

							foreach($LANG_dr_array as $file) {
								if ($file != "." && $file != ".." && $file != "Thumbs.db" && $file != ".DS_Store" && $file != "images") {
									$val_file = str_replace('.php', '', $file);
									if ($Tumd['config']['setting']['language'] == $val_file) {
										echo '<option value="'.$val_file.'" selected>'.$val_file.'</option>';
									} else {
										echo '<option value="'.$val_file.'">'.$val_file.'</option>';
									}
								}
							}
						?>
					</select>
				</div>
				<div class="_yt10">
					<div class="_a6">
						<label>
						<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/maintenance_status.png" width="20">
						<span class="_tr5 color-grey"><?=$lang['site_maintenance_status']?></span>
						<input type="checkbox" name="ss_maintenance" <?=($Tumd['config']['setting']['site_maintenance'] == 1)?'checked':''?>>
						</label>
					</div>
					<div class="_a6 pull-right">
						<label>
						<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/ads.png" width="20">
						<span class="_tr5 color-grey"><?=$lang['site_ads_status']?></span>
						<input type="checkbox" name="ss_ads" <?=($Tumd['config']['setting']['ads_status'] == 1)?'checked':''?>>
						</label>
					</div>
				</div>
			</div>
			<!--# STATUS AND ADS SECTION #-->
			<div class="r05-t _b-t _5e4">
				<div class="_yt1">
					<span class="_tr5 _yt5 color-grey"><?=$lang['site_maintenance_message']?></span>
					<div class="_input-box">
						<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/maintenance.png">
						<input class="_text-input" type="text" name="ss_maintenance_msg" value="<?=$Tumd['config']['setting']['maintenance_msg']?>">
					</div>
				</div>
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				<?=$lang['save']?>
			</button>
		</div>
	</form>
</div>
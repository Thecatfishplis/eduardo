<?php if ( defined("PILOT_GLOBAL") != true) { die(); }
if (!isset($_GET['action']) OR $_GET['action'] == "view") { ?>
<div class="tumd-main-headself">
	<i class="fa fa-gamepad"></i>
</div>

<?php $sql_global_games = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE game_id!=0 ORDER BY date_added DESC");
	if ($sql_global_games->num_rows != 0) {
?>
<ul class="_manage--games-list scroll-custom _y20">
<?php
	while ($global_games = mysqli_fetch_array($sql_global_games)) {
		$mng_pubAct = ($global_games['published'] == 1) ? 'pub-active':'';
		$mng_featAct = ($global_games['featured'] == 1) ? 'feat-active':'';
?>
	<li id="manage--game" class="__mg-<?=$global_games['game_id']?> __game-actions _pr _a-c">
		<img src="<?=$global_games['image']?>" class="img-circle" width="60" height="60">
		<div class="_cR3-p ellipsis"><?=$global_games['name']?></div>
		<div class="manage--p _p">
			<div>
				<i id="mg--published" class="mg_p-<?=$global_games['game_id']?> fa fa-globe icon-18 <?=$mng_pubAct?>" data-game="<?=$global_games['game_id']?>" data-pb="<?=$global_games['published']?>"></i>
				<i id="mg--featured" class="mg_f-<?=$global_games['game_id']?> fa fa-heart icon-18 <?=$mng_featAct?>" data-game="<?=$global_games['game_id']?>" data-ft="<?=$global_games['featured']?>"></i>
			</div>
			<div>
				<a href="<?=siteUrl()?>/admin/games/edit/<?=$global_games['game_id']?>"><i class="fa fa-pencil icon-18 _mg-edit-ic" title="<?=$lang['edit']?>"></i></a>
				<i id="mg--delete" class="mg_d-<?=$global_games['game_id']?> fa fa-trash icon-18" data-game="<?=$global_games['game_id']?>" title="<?=$lang['delete']?>"></i>
			</div>
		</div>
	</li>
<?php } ?>
</ul>
<?php } else { ?>
<div class="_a-c _e55">
	<div>
		<img src="<?=$Tumd['theme_url']?>/image/icon-color/controller.png">
	</div>
	<h3 class="color-grey"><?=$lang['no_games']?></h3>
</div>
<?php } } elseif (isset($_GET['action']) && $_GET['action'] == "edit" && !empty($_GET['gid'])) {
	$game_id = secureEncode($_GET['gid']);
	$sql_select_editgame = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE game_id='{$game_id}'");
	if ($sql_select_editgame->num_rows == 1) {
		$edit_game = mysqli_fetch_array($sql_select_editgame);
?>
<div class="general-box _y9 _0e4">
	<div class="_5e4 _b-b">
		<img id="editgame_image" width="40" height="40" class="img-circle" src="<?=$edit_game['image']?>">
		<span id="editgame_name"><?=$edit_game['name']?></span>
	</div>
	<form id="editgame-form" enctype="multipart/form-data" method="POST">
		<div class="g-d5 games-dashboard">
			<div class="r05-t _b-r _5e4">
				<div class="_input-box">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/name.png">
					<input type="text" name="eg_name" class="_text-input _tr5" value="<?=$edit_game['name']?>">
				</div>
				<div>
					<textarea name="eg_description" class="_text-input _tr5"><?=$edit_game['description']?></textarea>
				</div>
				<div>
					<textarea name="eg_instructions" class="_text-input _tr5"><?=$edit_game['instructions']?></textarea>
				</div>
				<div>
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/category.png" width="20">
					<span class="_tr5"><?=$lang['game_category']?></span>
					<select name="eg_category" class="_p4s8">
						<?php 
							$addgame_category = $Tumdconnect->query("SELECT * FROM ".CATEGORIES." WHERE id!=0");
							while ($select_category = mysqli_fetch_array($addgame_category)) {
								if ($edit_game['category'] == $select_category['id']) {
									echo '<option value="'.$select_category['id'].'" selected>'.$select_category['name'].'</option>';
								} else {
									echo '<option value="'.$select_category['id'].'">'.$select_category['name'].'</option>';
								}
							}
						?>
					</select>
				</div>
			</div>
			<div class="r05-t _5e4">
				<div>
					<div class="_cE3-xf">
						<button type="button" class="game_type-import i-t-0 fa fa-pencil icon-22"></button>
						<button type="button" class="game_type-import i-t-1 fa fa-cloud-upload icon-22"></button>
					</div>
		
					<div id="game_import0">
						<div class="_input-box">
							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/image.png">
							<input type="text" name="eg_image" class="_text-input _tr5" value="<?=$edit_game['image']?>">
						</div>
						<div class="_input-box">
							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file.png">
							<input type="text" name="eg_file" class="_text-input _tr5" value="<?=$edit_game['file']?>">
						</div>
					</div>

					<div id="game_import1"  class="game_import-filepanel r-r3 _10e4 _a0">
						<div>
							<label>
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/image.png" width="20">
								<span class="_tr5"><?=$lang['game_image']?></span>
								<input id="_-2m-f" type="file" name="__eg_image">
							</label>
						</div>
						<div>
							<label>
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file.png" width="20">
								<span class="_tr5"><?=$lang['game_file']?></span>
								<input id="_-3f-f" type="file" name="__eg_file">
							</label>
						</div>
						<div class="editgame_progress progress _a0">
        					<div class="editgame_bar progress-bar progress-bar-success"></div>
    					</div>
    				</div>
					<div class="_tr5 _bold"><?=$lang['game_size']?></div>
    				<div class="_cE3-xf">
    					<div class="_cE3-x7">
    						<div class="_input-box">
    							<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/width.png">
    							<input type="number" class="_text-input _tr5" name="eg_width" value="<?=$edit_game['w']?>">
    						</div>
						</div>
						<div class="_cE3-x7">
							<div class="_input-box">
								<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/height.png">
								<input type="number" class="_text-input _tr5" name="eg_height" value="<?=$edit_game['h']?>">
							</div>
						</div>
					</div>
					<div>
    					<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/file_type.png" width="20">
    					<select name="eg_file_type" class="_p4s8">
							<option value="swf" <?=($edit_game['game_type'] == 'swf')?'selected':''?>><?=$lang['game_type_swf']?></option>
							<option value="other" <?=($edit_game['game_type'] != 'swf')?'selected':''?>><?=$lang['game_type_html']?></option>
						</select>
					</div>
				</div>
				<input type="hidden" class="game_type-import--val" name="eg_import" value="0">
				<input type="hidden" name="eg_id" value="<?=secureEncode($_GET['gid'])?>">
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<label>
				<img src="<?=$Tumd['theme_url']?>/image/icon-color/admin/rating.png" width="20">
				<select name="eg_rating" class="_p4s8">
					<option value="0" <?=($edit_game['rating']==0)?'selected':''?>>0</option>
					<option value="0.5" <?=($edit_game['rating']==0.5)?'selected':''?>>0.5</option>
					<option value="1" <?=($edit_game['rating']==1)?'selected':''?>>1</option>
					<option value="1.5" <?=($edit_game['rating']==1.5)?'selected':''?>>1.5</option>
					<option value="2" <?=($edit_game['rating']==2)?'selected':''?>>2</option>
					<option value="2.5" <?=($edit_game['rating']==2.5)?'selected':''?>>2.5</option>
					<option value="3" <?=($edit_game['rating']==3)?'selected':''?>>3</option>
					<option value="3.5" <?=($edit_game['rating']==3.5)?'selected':''?>>3.5</option>
					<option value="4" <?=($edit_game['rating']==4)?'selected':''?>>4</option>
					<option value="4.5" <?=($edit_game['rating']==4.5)?'selected':''?>>4.5</option>
					<option value="5" <?=($edit_game['rating']==5)?'selected':''?>>5</option>
				</select>
			</label>
			<button type="submit" id="addgame-btn" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				<?=$lang['save_game']?>
			</button>
		</div>
	</form>
</div>
<?php } else { 
			echo incPage('welcome/error-section'); 
		} } else { 
				echo incPage('welcome/error-section'); 
			} 
?>
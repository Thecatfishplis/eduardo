<?php if ( defined("PILOT_GLOBAL") != true) { die(); }

if (!isset($_GET['page']) OR $_GET['page'] == "list") { ?>
	<div class="tumd-main-headself">
		<i class="fa fa-book"></i>
	</div>
	<div class="box_feed_getbutton">
		<div class="games-dealers-container r-r3 _y9">
			<ul class="games-dealers _y9 _10e4 r-r3">
				<li class="g-d5 _j4">
					<div class="dealers-logobox">
						<img src="<?=siteUrl()?>/static/libs/images/feed-logos/kongregate.png">
					</div>
					<div>
						<button data-href="<?=siteUrl()?>/admin/catalog/1" class="btn-p btn-p1 fa fa-eye icon-18 icon-middle"></button>
						<button id="getGameData" data-feed="1" data-feed-alert="true" class="btn-p btn-p4 fa fa-download icon-18 icon-middle"></button>
					</div>
				</li>
				<li class="g-d5 _j4">
					<div class="dealers-logobox">
						<img src="<?=siteUrl()?>/static/libs/images/feed-logos/spilgames.png">
					</div>
					<div>
						<button data-href="<?=siteUrl()?>/admin/catalog/2" class="btn-p btn-p1 fa fa-eye icon-18 icon-middle"></button>
						<button id="getGameData" data-feed="2" data-feed-alert="true" class="btn-p btn-p4 fa fa-download icon-18 icon-middle"></button>
					</div>
				</li>
				<li class="g-d5 _j4">
					<div class="dealers-logobox">
						<img src="<?=siteUrl()?>/static/libs/images/feed-logos/gamepix.png">
					</div>
					<div>
						<button data-href="<?=siteUrl()?>/admin/catalog/3" class="btn-p btn-p1 fa fa-eye icon-18 icon-middle"></button>
						<button id="getGameData" data-feed="3" data-feed-alert="true" class="btn-p btn-p4 fa fa-download icon-18 icon-middle"></button>
					</div>
				</li>
			</ul>
			<img class="tumd-loader _a0 _ld-circle img-circle" src="<?=siteUrl()?>/static/libs/images/ajax-spinner.svg">
		</div>
	</div>
<?php } elseif (isset($_GET['page']) && $_GET['page'] == "catalog-1") { 
		echo incPage('admin/feeds/feed.kongregate');
	  } elseif (isset($_GET['page']) && $_GET['page'] == "catalog-2") { 
		echo incPage('admin/feeds/feed.spilgames');
	  } elseif (isset($_GET['page']) && $_GET['page'] == "catalog-3") { 
	  	echo incPage('admin/feeds/feed.gamepix');
	  } else { echo incPage('welcome/error-section'); }
?>
<?php if ( defined("PILOT_GLOBAL") != true) { die(); } 
	$ads_select_sql = $Tumdconnect->query("SELECT * FROM ".ADS.""); 
	$ads_select = mysqli_fetch_object($ads_select_sql);
?>
<div class="tumd-main-headself">
	<i class="fa fa-flag-o"></i>
</div>
<div class="general-box _y9 _0e4">
	<form id="adsArea-form" method="POST">
		<div class="g-d5">
			<div class="r05-t _b-r _5e4">
				<span class="_f12 color-grey"><?=$lang['ads_header']?></span>
				<textarea class="b-input" name="ad_header"><?=decodeHTML($ads_select->header)?></textarea>
				<span class="_f12 color-grey"><?=$lang['ads_footer']?></span>
				<textarea class="b-input" name="ad_footer"><?=decodeHTML($ads_select->footer)?></textarea>
				<span class="_f12 color-grey"><?=$lang['ads_footer']?></span>
				<textarea class="b-input" name="ad_column_one"><?=decodeHTML($ads_select->column_one)?></textarea>
			</div>
			<div class="r05-t _5e4">
				<span class="_f12 color-grey"><?=$lang['ads_game_section_top']?></span>
				<textarea class="b-input" name="ad_gameTop"><?=decodeHTML($ads_select->gametop)?></textarea>
				<span class="_f12 color-grey"><?=$lang['ads_game_section_bottom']?></span>
				<textarea class="b-input" name="ad_gameBottom"><?=decodeHTML($ads_select->gamebottom)?></textarea>
				<span class="_f12 color-grey"><?=$lang['ads_game_section_info']?></span>
				<textarea class="b-input" name="ad_gameInfo"><?=decodeHTML($ads_select->gameinfo)?></textarea>
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				<?=$lang['save']?>
			</button>
		</div>
	</form>
</div>
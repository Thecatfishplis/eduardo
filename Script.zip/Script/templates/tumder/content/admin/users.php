<?php if ( defined("PILOT_GLOBAL") != true) { die(); }

if (isset($_GET['action']) && $_GET['action'] == "edit" && !empty($_GET['uid'])) {
		$uid_pilotedit = secureEncode($_GET['uid']);
		if (is_numeric($uid_pilotedit)) {
        	$ss_user_dtype = "id = " . $uid_pilotedit;
    	} elseif (preg_match('/[A-Za-z0-9_]/', $uid_pilotedit)) {
        	$ss_user_dtype = "username = '{$uid_pilotedit}'";
    	}

    	$sql_euAccount_query = $Tumdconnect->query("SELECT * FROM ".ACCOUNTS." WHERE $ss_user_dtype");
    	if ($sql_euAccount_query->num_rows == true) {
    		$euAccount_array = mysqli_fetch_array($sql_euAccount_query);
    		$sql_euData_query = $Tumdconnect->query("SELECT * FROM ".USERS." WHERE user_id='{$euAccount_array['id']}'");
    		$euData_array = mysqli_fetch_array($sql_euData_query);

    		$photo_avatar = getAvatar($euAccount_array['avatar_id'], $euData_array['gender']);
			$mySelf_profile = ($euAccount_array['id'] == $Tumd['data']['id']) ? '<div class="_a6 _top-editmyself color-grey"><i class="fa fa-circle icon-18 icon-middle"></i> '.$lang['my_profile'].'</div>':'';

?>
<div class="general-box box-m _0e4">
	<form id="edituser-form" type="POST">
		<div class="_top-edituser">
			<div class="_a-c _top-userpic">
				<img class="img-circle" src="<?=$photo_avatar?>" width="100" height="100">
			</div>
			<?=$mySelf_profile?>
		</div>
		<div class="_5e4">
			<span class="_f12 color-grey"><?=$lang['user']?></span>
			<input class="b-input" name="eu_username" value="<?=$euAccount_array['username']?>">
			<span class="_f12 color-grey"><?=$lang['name']?></span>
			<input class="b-input" name="eu_name" value="<?=$euAccount_array['name']?>">
			<span class="_f12 color-grey"><?=$lang['ip_address']?></span>
			<input class="b-input" value="<?=$euAccount_array['ip']?>" disabled>
			<div>
				<span class="_f12 color-grey"><?=$lang['user_rank']?></span>
				<select class="_p4s8 _yb5" name="eu_admin">
					<option value="0" <?=($euAccount_array['admin'] == 0)?'selected':''?>><?=$lang['status_user']?></option>
					<option value="1" <?=($euAccount_array['admin'] == 1)?'selected':''?>><?=$lang['status_admin']?></option>
				</select>
			</div>
			<span class="_f12 color-grey"><?=$lang['email']?></span>
			<input class="b-input" name="eu_email" value="<?=$euAccount_array['email']?>">
			<span class="_f12 color-grey"><?=$lang['xp_points']?></span>
			<input class="b-input" name="eu_xp" type="number" value="<?=$euAccount_array['xp']?>">
			<div>
				<span class="_f12 color-grey"><?=$lang['lang']?></span>
				<select class="_p4s8 _yb5" name="eu_lang">
						<?php
							$ueLANG_dir = opendir('assets/language/');
							$ueLANG_dr_array = array();
							while (false !== ($file = readdir($ueLANG_dir))) {
								$ueLANG_dr_array[] = $file;
							}
							closedir($ueLANG_dir);

							foreach($ueLANG_dr_array as $file) {
								if ($file != "." && $file != ".." && $file != "Thumbs.db" && $file != ".DS_Store" && $file != "images") {
									$val_file = str_replace('.php', '', $file);
									echo ($euAccount_array['language'] == $val_file) ? '<option value="'.$val_file.'" selected>'.$val_file.'</option>' : '<option value="'.$val_file.'">'.$val_file.'</option>';
								}
							}
						?>
				</select>
			</div>
			<span class="_f12 color-grey"><?=$lang['user_about']?></span>
			<div><textarea class="b-input" name="eu_about"><?=$euData_array['about']?></textarea></div>
			
			<div>
				<span class="_f12 color-grey"><?=$lang['user_gender']?></span>
				<select class="_p4s8 _yb5" name="eu_gender">
					<option value="1" <?=($euData_array['gender'] == 1)?'selected':''?>><?=$lang['male']?></option>
					<option value="2" <?=($euData_array['gender'] == 2)?'selected':''?>><?=$lang['female']?></option>
				</select>
			</div>
			<div>
				<label>
					<input type="checkbox" name="eu_active" <?=($euAccount_array['active'] == 1)?'checked':''?>>
					<?=$lang['user_active']?>
				</label>
			</div>
			<input name="eu_id" type="hidden" value="<?=$euAccount_array['id']?>">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				<?=$lang['save']?>
			</button>
		</div>
	</form>
</div>
<?php } else { 
	echo incPage('welcome/error');
} } else { ?>
	<div class="tumd-main-headself">
		<i class="fa fa-user"></i>
	</div>
	<div class="general-box box-m _0e4">
		<div class="header-box">
			<i class="fa fa-search color-w icon-middle"></i>
		</div>
		<div class="_5e4">
			<form id="search-useredit-form" method="POST">
				<div class="vByg5">
					<input type="text" name="uid" placeholder="<?=$lang['id_username']?>">
				</div>
				<button type="submit" class="btn-p btn-p1">
					<i class="fa fa-search icon-middle"></i>
					<?=$lang['search']?>
				</button>
			</form>
		</div>
	</div>
<?php } ?>
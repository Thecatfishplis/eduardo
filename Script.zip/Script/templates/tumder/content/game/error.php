<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<div class="tumd-main span100">
	<div class="_a-c _e55">
		<div>
			<img src="<?=$Tumd['theme_url']?>/image/icon-color/kite.png">
		</div>
		<h3 class="color-grey"><?=$lang['error_game_404']?></h3>
	</div>
</div>
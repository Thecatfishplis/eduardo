<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<section>
	<div class="game-container">
		<div class="game-content">
			<div class="game-case">
				<div class="iframe-wrapper">
					<?php 
						$adsDisplay = ($Tumd['config']['setting']['ads_status'] == 1) ? '_a0':'';
						if($Tumd['config']['setting']['ads_status'] == 1) { ?>
						<div class="_Ad-game">
							<div class="_a-r">
								<button class="_removeAd" disabled>
									<span class="__r-Ad-1">
										<span class="rAdNum">0</span>
										<?=$lang['seconds_to_remove_ads']?>
									</span>
									<span class="__r-Ad-2 _a0">
										<i class="fa fa-close"></i>
										<?=$lang['remove_ads']?>
									</span>
								</button>
							</div>
							<?=$Tumd['ads']['gametop']?>
							<div class="AdCountDown">
								<img src="<?=siteUrl()?>/static/libs/images/ajax-spinner.svg" width="100%" height="100%">
								<span class="Adnum">0</span>
							</div>
							<?=$Tumd['ads']['gamebottom']?>
						</div>
					<?php } ?>

					<div class="gmDisplay <?=$adsDisplay?>">
						<?=$Tumd['game']['data']['embed']?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<section class="game-info">
		<div class="game-connect-box">
			<div class="game-content">
				<header class="main-info">
					<div class="info-self">
						<span class="game-thumbnail pull-left">
							<img src="<?=$Tumd['game']['data']['image_url']?>" width="60" height="41">
						</span>
						<hgroup class="pull-left">
							<h1 class="ellipsis"><?=$Tumd['game']['data']['name']?></h1>
							<div class="meter mtr-2" value="<?=$Tumd['game']['rating']?>" title="<?=$Tumd['game']['rating']?> <?=$lang['of_5_stars']?>"></div>
						</hgroup>
					</div>
					<ul class="set-btn h-list pull-right">
						<li>
							<?php if($Tumd['access'] == true) { ?>	
							<button class="top-gm-btn fav-status-button fa fa-star <?=$Tumd['game']['favorite_status']?>" id="fav-btn" data-game="<?=$Tumd['game']['data']['game_id']?>"></button>
							<?php } else { ?>
							<button class="top-gm-btn fav-status-button fa fa-star" data-href="<?=siteUrl()?>/login/url/play/<?=$Tumd['game']['id']?>"></button>
							<?php } ?>
						</li>
						<li>
							<button class="top-gm-btn fs-action-button initFullScreen fa fa-arrows-alt" data-fullscreen-item=".iframe-wrapper"></button>
						</li>
						<li>
							<button class="top-gm-btn rpt-action-button fa fa-exclamation-circle" id="report-btn" data-report="<?=$Tumd['game']['data']['game_id']?>"></button>
						</li>
						<li>
							<?=$Tumd['game']['data']['admin_edit']?>
						</li>
					</ul>
				</header>
			</div>
		</div>
	</section>
</section>
<div class="page-wrapper tumd-container">
	<div class="pull-left span69">
		<div class="tumd-main main-box">
			<div class="_a-c g-top-group share-section">
				<!-- Facebook -->
				<a class="share-btn facebook" id="share-btn" data-share-url="https://www.facebook.com/share.php?u=<?=$Tumd['game']['data']['game_url']?>">Facebook</a>
				
				<!-- Twitter -->
				<a class="share-btn twitter" id="share-btn" data-share-url="https://twitter.com/intent/tweet?text=<?=$Tumd['game']['data']['name']?> - <?=shortStr($Tumd['game']['data']['description'], 45)?>&url=<?=$Tumd['game']['data']['game_url']?>&original_referer=<?=$Tumd['game']['data']['game_url']?>">Twitter</a>
				
				<!-- Google+ -->
				<a class="share-btn google" id="share-btn" data-share-url="https://plus.google.com/share?url=<?=$Tumd['game']['data']['game_url']?>">Google+</a>
			</div>
			<div class="g-top-group o-hidden b-dsh-top">
				<div class="game-txt-info pull-left">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/calendar.png" class="img-30">
					<?=$Tumd['game']['data']['date_added']?>
				</div>
				<div class="game-txt-info pull-right">
					<img src="<?=$Tumd['theme_url']?>/image/icon-color/controller.png" class="img-30">
					<?=$Tumd['game']['data']['plays']?>
				</div>
			</div>
			<div class="game-txt-info g-group _a-c b-dsh-top">
				<p>
					<strong><?=$lang['description']?></strong>
				</p>
				<span><?=$Tumd['game']['data']['description']?></span>
			</div>
			<div class="game-txt-info g-group _a-c b-dsh-top">
				<p>
					<strong><?=$lang['instructions']?></strong>
				</p>
				<span><?=$Tumd['game']['data']['instructions']?></span>
			</div>
		</div>
		<?=incPage('game/random')?>
	</div>
	<div class="container-widget pull-right span30">
		<aside>
			<?=incPage('game/sections/widget.top-stars')?>
		</aside>
	</div>
</div>
<?=$Tumd['ads']['gameinfo']?>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<ul class="card">
<?php
	$sql_most_query = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE published='1' ORDER BY plays DESC LIMIT ".$Tumd['config']['setting']['mp_game_limit']);
	while($mostplayed_games = mysqli_fetch_array($sql_most_query)) {
		$pilot_game = gameData($mostplayed_games);	
?>
	<li class="card-item">
		<figure class="card-game">
			<?php if($mostplayed_games['featured'] == true) { ?>
			<span class="card-icon-corner"></span>
			<i class="fa fa-heart icon-18 icon-corner"></i>
			<?php } ?>
			<a class="g-media" data-href="<?=$pilot_game['game_url']?>" href="<?=$pilot_game['game_url']?>">
				<img src="<?=$pilot_game['image_url']?>" width="140px" height="96px">
				<span class="name ellipsis"><?=$pilot_game['name']?></span>
				<div class="meter mtr-2" value="<?=$mostplayed_games['rating']?>" title="<?=$mostplayed_games['rating']?> <?=$lang['of_5_stars']?>"></div>
				<figcaption class="caption">
					<div class="plays">
						<span class="fa fa-gamepad"></span>
						<span class="plays-num"><?=numberFormat($mostplayed_games['plays'])?></span>
					</div>
				</figcaption>
			</a>
			<span class="cb-pro"></span>
		</figure>
	</li>
<?php } ?>
</ul>
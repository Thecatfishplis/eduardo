<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<div class="container-widget pull-right span30">
	<?php if ($Tumd['config']['setting']['ads_status'] == 1) { ?>
	<aside>
		<?=$Tumd['ads']['column_one']?>
	</aside>
	<?php } ?>
	<aside>
		<?=incPage('game/sections/widget.top-stars')?>
	</aside>
	<aside>
		<?=incPage('game/sections/widget.top-users')?>
	</aside>
	<aside>
		<?=incPage('game/sections/widget.random-games')?>
	</aside>
</div>
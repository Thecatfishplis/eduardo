<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<div class="widget">
	<div class="widget-header">
		<a class="t-c3">
			<i class="fa fa-cube color-f"></i>
			<?=$lang['random_games']?>
		</a>
	</div>
    <ul class="widget-list">
    	<?php
    		$query_gm_Random = $Tumdconnect->query("SELECT game_id,name,image,rating FROM ".GAMES." WHERE published='1' ORDER BY rand() LIMIT 5");
    		if ($query_gm_Random->num_rows != 0) {
				while ($gRandom = $query_gm_Random->fetch_array()) {
					$gmRandom = gameData($gRandom);
		?>
		<li class="item">
			<a class="item-thumbnail pull-left" href="<?=$gmRandom['game_url']?>">
				<img src="<?=$gmRandom['image_url']?>" width="60px" height="41px">
			</a>
			<div class="body pull-left">
				<div class="title ellipsis">
					<a href="<?=$gmRandom['game_url']?>" title="<?=$lang['play_to']?> <?=$gmRandom['name']?>"><?=$gmRandom['name']?></a>
				</div>
				<div class="meter mtr-2" value="<?=$gRandom['rating']?>"></div>
			</div>
		</li>
		<?php } } else { ?>
			<li class="item">
				<div class="color-grey small _a-c"><?=$lang['no_games_found']?></div>
			</li>
		<?php } ?>
	</ul>
</div>
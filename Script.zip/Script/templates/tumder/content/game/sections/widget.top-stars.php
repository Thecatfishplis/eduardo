<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<div class="widget">
	<div class="widget-header">
		<a class="t-c3">
			<i class="fa fa-star color-e"></i>
			<?=$lang['top_stars']?>
		</a>
	</div>
    <ul class="widget-list">
    	<?php
    		$query_gm_topStar = $Tumdconnect->query("SELECT game_id,name,image,rating FROM ".GAMES." ORDER BY rating DESC, date_added DESC LIMIT 5");
    		if ($query_gm_topStar->num_rows != 0) {
				while ($topStar = $query_gm_topStar->fetch_array()) {
					$game_top = gameData($topStar);
		?>
		<li class="item">
			<a class="item-thumbnail pull-left" href="<?=$game_top['game_url']?>">
				<img src="<?=$game_top['image_url']?>" width="60px" height="41px">
			</a>
			<div class="body pull-left">
				<div class="title ellipsis">
					<a href="<?=$game_top['game_url']?>" title="<?=$lang['play_to']?> <?=$game_top['name']?>"><?=$game_top['name']?></a>
				</div>
				<div class="meter mtr-2" value="<?=$topStar['rating']?>"></div>
			</div>
		</li>
		<?php } } else { ?>
			<li class="item">
				<div class="color-grey small _a-c"><?=$lang['no_games_found']?></div>
			</li>
		<?php } ?>
	</ul>
</div>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<div class="widget">
	<div class="widget-header">
		<a class="t-c3">
			<i class="fa fa-star-half-o color-g"></i>
			<?=$lang['top_users_xp']?>
		</a>
	</div>
    <ul class="widget-list">
    	<?php
    		$sql_community_xp_query = $Tumdconnect->query("SELECT id,avatar_id,username,name,xp FROM ".ACCOUNTS." WHERE active='1' AND admin!='1' ORDER BY xp DESC LIMIT 3");
    		if ($sql_community_xp_query->num_rows != 0) {
    			$i=0;
				while ($community_xp = $sql_community_xp_query->fetch_array()) {
					$userinfo_xp = getInfo($community_xp['id']);
					$photo_avatar = getAvatar($community_xp['avatar_id'], $userinfo_xp->gender, 'thumb');
					$i++;
					$top_xp_medal = '';
					if ($i == 1) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_1.png'; } 
					elseif ($i == 2) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_2.png'; } 
					elseif ($i == 3) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_3.png'; }
		?>
		<li class="item">
			<a class="item-thumbnail pull-left" href="<?=siteUrl()?>/profile/<?=$community_xp['username']?>">
				<img src="<?=$photo_avatar?>" width="60px" height="60px">
			</a>
			<div class="body pull-left">
				<div class="title ellipsis">
					<a href="<?=siteUrl()?>/profile/<?=$community_xp['username']?>"><?=$community_xp['name']?><a>
				</div>
				<div>
					<?php if ($i <= 3){ ?>
					<img src="<?=$top_xp_medal?>" width="18">
					<?php } ?>
				</div>
			</div>
		</li>
		<?php } } else { ?>
			<li class="item">
				<div class="color-grey small _a-c"><?=$lang['no_users_found']?></div>
			</li>
		<?php } ?>
	</ul>
</div>
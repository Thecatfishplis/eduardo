<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
<div id="newgames-carousel" class="owl-carousel owl-theme">
<?php
	$sql_new_query = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE published='1' ORDER BY date_added DESC LIMIT 7");
	while($new_games = mysqli_fetch_array($sql_new_query)) {
		$pilot_game = gameData($new_games);
?>
	<div class="item-c-media" data-href="<?=$pilot_game['game_url']?>">
		<span class="game-c-media">
			<img src="<?=$pilot_game['image_url']?>">
		</span>
		<h1 class="c-title ellipsis"><?=$pilot_game['name']?></h1>
		<div class="c-info">
			<div class="c-subtitle">
				<div class="meter mtr-2" value="<?=$new_games['rating']?>" title="<?=$new_games['rating']?> <?=$lang['of_5_stars']?>"></div>
			</div>
		</div>
		<img class="game-b-media-img" src="<?=$pilot_game['image_url']?>">
	</div>
<?php } ?>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$("#newgames-carousel").owlCarousel({
			items: 2,
			autoPlay: true
		});
	});
</script>
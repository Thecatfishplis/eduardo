<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }?>
<ul class="nav-footer">
	<li><a data-href="<?=siteUrl()?>/home/english"><?=$lang['en']?></a></li>
	<li><a data-href="<?=siteUrl()?>/home/spanish"><?=$lang['es']?></a></li>
	<li class="full">&copy; <?=$Tumd['config']['setting']['site_name']?> 2016</li>
</ul>
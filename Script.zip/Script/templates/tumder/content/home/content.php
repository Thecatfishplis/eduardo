<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<?=$Tumd['ads']['header']?>
<div class="page-wrapper">
	<div class="tumd-main main-box pull-left span69">
		<div class="tumd-section-s landing-pattern">
			<div class="_content-title _a-l">
				<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/new.png"> <?=$lang['new_games']?>
			</div>
			<?=incPage('game/games-new')?>
		</div>
		<div class="tumd-game-featured _a-c">
			<span class="_content-title _content-color-a _a-l"><img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/heart.png"> <?=$lang['featured_games']?></span>
			<?=incPage('game/games-featured')?> 
		</div>
		<div class="tumd-main-content games-m-played">
			<span class="_content-title"><img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/crown.png"> <?=$lang['most_played']?></span>
		<?=incPage('game/games-mostplayed')?> 
		</div>
	</div>
	<?=incPage('game/section-main')?>
</div>
<?=$Tumd['ads']['footer']?>
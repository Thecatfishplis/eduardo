<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }?>
	<ul class="community-leaderboard">
		<?php $i=0;
			$sql_community_xp_query = $Tumdconnect->query("SELECT * FROM ".ACCOUNTS." WHERE active='1' AND admin!='1' ORDER BY xp DESC LIMIT 20");
			while ($community_xp = mysqli_fetch_array($sql_community_xp_query)) {
				$userinfo_xp = mysqli_fetch_array($Tumdconnect->query("SELECT gender FROM ".USERS." WHERE user_id='{$community_xp['id']}'"));
				$photo_avatar = getAvatar($community_xp['avatar_id'], $userinfo_xp['gender'], 'medium');
				
				$i++;
				$top_xp = ($i <= 3) ? '_community-top-xp':'_community-xp';
				$top_xp_medal = '';
				if ($i == 1) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_1.png'; } 
				elseif ($i == 2) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_2.png'; } 
				elseif ($i == 3) { $top_xp_medal = $Tumd['theme_url'].'/image/icon-color/medal_3.png'; }
		?>
		<li>
			<span class="community-position">
				<?php if ($i <= 3){ ?>
					<img src="<?=$top_xp_medal?>" width="18">
				<?php } else { ?>
				<?php echo $i; } ?>
			</span>
			<a data-href="<?=siteUrl()?>/profile/<?=$community_xp['username']?>">
				<img class="community-avatar <?=$top_xp?>" src="<?=$photo_avatar?>">
				<div class="community-name ellipsis"><?=$community_xp['username']?></div>
			</a>
			<div class="community-xp <?=$top_xp?> ellipsis" title="<?=$community_xp['xp']?> <?=$lang['xp']?>"><?=shortStr($community_xp['xp'], 8)?> XP</div>
			<?php if($Tumd['access'] == true && $Tumd['data']['admin'] == true) { ?>
				<button class="admin-user-btn" data-href="<?=siteUrl()?>/admin/users/edit/<?=$community_xp['username']?>">
					<i class="fa fa-wrench"></i>
				</button>
			<?php } ?>
		</li>
		<?php } ?>
	</ul>
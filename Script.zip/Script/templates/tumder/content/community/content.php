<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }?>

<div class="tumd-main span100">
	<div class="_header-section">
		<span class="_content-title _content-color-a"><img class="img-50" src="<?=$Tumd['theme_url']?>/image/icon-color/globe.png"> <?=$lang['community']?></span>
	</div>
	<div class="general-box _yt10 _yb10">
		<span class="_content-title"><img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/leaderboard.png"> <?=$lang['top_xp']?></span>
		<?=incPage('community/community-xp')?>
	</div>
	<?=$Tumd['ads']['footer']?>
</div>
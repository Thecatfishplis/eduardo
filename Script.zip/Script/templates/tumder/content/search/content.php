<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<div class="tumd-main main-box span100">
<?php
	if(isset($_GET['q']) && !empty($_GET['q'])) {
		$search_parameter = secureEncode($_GET['q']);
		$search_query = searchGames($search_parameter);
?>
<div class="_0e4">
	<div class="_b-b _10e4 color-grey">
		<i class="fa fa-search"></i> 
		<?=$lang['search_to']?> 
		<strong><?=$search_parameter?></strong>
	</div>
	<div class="_10e4">
<?php if ($search_query == true) { ?>
		<ul class="card">
<?php foreach ($search_query as $search_result) {
		$search_pilot = gameData($search_result);
?>
			<li class="card-item">
				<figure class="card-game">
					<?php if($search_result['featured'] == true) { ?>
					<span class="card-icon-corner"></span>
					<i class="fa fa-heart icon-18 icon-corner"></i>
					<?php } ?>
					<a class="g-media" data-href="<?=$search_pilot['game_url']?>" href="<?=$search_pilot['game_url']?>">
						<img src="<?=$search_pilot['image_url']?>" width="140px" height="96px">
						<span class="name ellipsis"><?=$search_pilot['name']?></span>
						<div class="meter mtr-2" value="<?=$search_result['rating']?>" title="<?=$search_result['rating']?> <?=$lang['of_5_stars']?>"></div>
						<figcaption class="caption">
							<div class="plays">
								<span class="fa fa-gamepad"></span>
								<span class="plays-num"><?=numberFormat($search_result['plays'])?></span>
							</div>
						</figcaption>
					</a>
					<span class="cb-pro"></span>
				</figure>
			</li>
<?php } ?>
		</ul>
<?php } else { ?>
		<div class="alert warning"><?=$lang['search_alert_msg']?></div>
<?php } ?>
	</div>
</div>
<?php } else { 
	echo incPage('search/error');
} ?>
</div>
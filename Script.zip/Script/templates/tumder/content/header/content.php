<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }
	if ($Tumd['access'] == true) {
		$photo_avatar = getAvatar($Tumd['data']['avatar_id'], $Tumd['info']['gender'], 'thumb');
	}
	$Header_navAccess = ($Tumd['access'] == true) ? '_rP5':'';
?>
<div class="tumd-header">
	<div class="tumd-header-nav">
		<div class="_h-c">
			<div class="tumd-logo">
				<a class="spf-link" href="<?=siteUrl()?>/home">
					<img src="<?=siteUrl()?>/static/logo/td-logo.png" width="160" logo>
					<img src="<?=siteUrl()?>/static/logo/td-logo-responsive.png" width="35" logo-responsive>
				</a>
			</div>
			<div class="tumd-search">
				<form id="search-data-form" method="POST" autocomplete="off">
					<input class="search-input" id="Search-InArea" name="search_parameter" placeholder="<?=$lang['search_games']?>" type="text">
				</form>
			</div>
			<div class="nav-menu <?=$Header_navAccess?>">
				<div id="nav-icon">
  					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
			<div class="header-nav <?=$Header_navAccess?>">
				<ul>
					<li><a class="spf-link" href="<?=siteUrl()?>/community" title="<?=$lang['community']?>">
						<i class="fa fa-globe icon-22 icon-middle"></i>
						<span><?=$lang['community']?></span>
					</a></li>
					<li><a class="spf-link" href="<?=siteUrl()?>/categories" title="<?=$lang['categories']?>">
						<i class="fa fa-bookmark icon-22 icon-middle"></i>
						<span><?=$lang['categories']?></span>
					</a></li>
					<?php if($Tumd['access'] != true): ?>
					<li><a class="spf-link" button1 href="<?=siteUrl()?>/login">
						<?=$lang['sign_in']?>
					</a></li>
					<li><a class="spf-link" button2 href="<?=siteUrl()?>/signup">
						<?=$lang['sign_up']?>
					</a></li>
					<?php endif;?>
				</ul>
			</div>
			<script type="text/javascript">
				$('#nav-icon').click(function() { 
    				$('.header-nav').toggleClass('show-menu');
    				$(this).toggleClass('open');
  				});
			</script>
			<?php if($Tumd['access'] == true): ?>
				<div class="header-user">
					<a href="#" class="overlay-toggle" data-target="#userDropdown">
						<img class="img-circle header-user-image" src="<?=$photo_avatar?>" width="35">
					</a>
				</div>
				<div class="overlay-wrapper" id="userDropdown" data-status="closed">
					<nav class="overlay" data-direction="right">
						<div class="subnav">
							<div class="nav-wrapper">
								<a href="#" class="overlay-toggle" data-target="#userDropdown">
									<i class="fa fa-close overlay-close"></i>
								</a>
								<div class="user-overlay-header <?=$Tumd['data']['profile_theme']?>">
									<img class="img-circle overlay-user-picture" src="<?=$photo_avatar?>">
									<ul class="user-overlay-caption">
										<li>
											<span class="oui-txt-name">
												<?=$Tumd['data']['username']?>
											</span>
										</li>
										<li>
											<span class="icon-img">
												<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/star_xp.png">
											</span>
											<span class="icon-text" title="<?=$lang['my_xp_points']?>">
												<?=numberFormat($Tumd['data']['xp'])?>
											</span>
										</li>
									</ul>
								</div>
								<ul class="overlay-user-menu">
									<li>
										<a class="spf-link" href="<?=siteUrl()?>/profile/<?=$Tumd['data']['username']?>">
										<i class="fa fa-user-circle icon-middle"></i>
										<?=$lang['view_profile']?>
										</a>
									</li>
									<li>
										<a class="spf-link" href="<?=siteUrl()?>/setting">
										<i class="fa fa-wrench icon-middle"></i>
										<?=$lang['settings']?>
										</a>
									</li>
									<?php if($Tumd['data']['admin'] == true) { ?>
									<li>
										<a class="spf-link" href="<?=siteUrl()?>/admin">
										<i class="fa fa-cog icon-middle"></i>
										<?=$lang['admin_panel']?> 
										</a>
									</li>
									<?php } ?>
									<li>
										<a href="<?=siteUrl()?>/logout">
										<i class="fa fa-sign-out icon-middle"></i>
										<?=$lang['logout']?>
										</a>
									</li>
								</ul>
								<!-- Footer -->
								<?=incPage('footer/content')?>
								<div>
							</div>
						</div>
					</nav>
				</div>
			<?php endif; ?>
			</div>
		</div>
		<div class="tumd-page-loadbar"></div>
	</div>
</div>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }?>

<div class="tumd-main span100">
	<div class="_header-section">
		<span class="_content-title _content-color-a"><img class="img-50" src="<?=$Tumd['theme_url']?>/image/icon-color/joker.png"> <?=$lang['categories']?></span>
	</div>
	<?=$Tumd['ads']['header']?>
	<?php
		$sql_cat_query = $Tumdconnect->query("SELECT * FROM ".CATEGORIES."");
		while($category = mysqli_fetch_array($sql_cat_query)) {
	?>
	<div class="general-box _yt10 _yb10">
		<div>
			<span class="_content-title _a-l">
				<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/circles.png"> <?=$category['name']?>
			</span>
		</div>
		<ul class="card">
		<?php
			$sql_c_games_query = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE category = '{$category['id']}' AND published = '1' ORDER BY date_added DESC");
			while($cat_games = mysqli_fetch_array($sql_c_games_query)) {
				$pilot_category = gameData($cat_games);
		?>
			<li class="card-item">
				<figure class="card-game">
					<?php if($cat_games['featured'] == true) { ?>
					<span class="card-icon-corner"></span>
					<i class="fa fa-heart icon-18 icon-corner"></i>
					<?php } ?>
					<a class="g-media" data-href="<?=$pilot_category['game_url']?>" href="<?=$pilot_category['game_url']?>">
						<img src="<?=$pilot_category['image_url']?>" width="140px" height="96px">
						<span class="name ellipsis"><?=$pilot_category['name']?></span>
						<div class="meter mtr-2" value="<?=$cat_games['rating']?>" title="<?=$cat_games['rating']?> <?=$lang['of_5_stars']?>"></div>
					</a>
					<span class="cb-pro"></span>
				</figure>
			</li>
		<?php } ?>
		</ul>
	</div>
	<?php } ?>
	</div>
</div>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } 
	$theater_pages = array('play', 'profile');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?=incPage('html.head')?>
</head>
<body>
    <?=incPage('header/content')?>
    <div <?=(incCheck($theater_pages, $_GET['p'], 'scan'))? 'theater-mode':''?> class="tumd-page-tree tumd-container">
        <?=$Tumd['content']?>
    </div>
    <?=incPage('html.footer')?>
</body>
</html>
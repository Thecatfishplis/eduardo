<?php if ( defined("PILOT_GLOBAL") != true ) { die(); }
	if (isset($_GET['section'])) { $_data = $_GET['section']; } else { $_data = 'info'; }
?>	
	<ul>
		<li class="_4lf <?=listMenu($_data, 'info')?>">
			<a href="<?=siteUrl()?>/setting" class="_p spf-link"></a> 
			<i class="fa fa-cogs icon-middle"></i> <?=$lang['general']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'avatar')?>">
			<a href="<?=siteUrl()?>/setting/avatar" class="_p spf-link"></a> 
			<i class="fa fa-user-circle icon-middle"></i> <?=$lang['avatar']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'theme')?>">
			<a href="<?=siteUrl()?>/setting/theme" class="_p spf-link"></a> 
			<i class="fa fa-tint icon-middle"></i> <?=$lang['theme']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'logs')?>">
			<a href="<?=siteUrl()?>/setting/logs" class="_p spf-link"></a> 
			<i class="fa fa-flag icon-middle"></i> <?=$lang['logs']?>
		</li>
		<li class="_4lf <?=listMenu($_data, 'password')?>">
			<a href="<?=siteUrl()?>/setting/password" class="_p spf-link"></a> 
			<i class="fa fa-key icon-middle"></i> <?=$lang['change_password']?>
		</li>
	</ul>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<div class="page-wrapper">
<div class="tumd-main pull-right span79">
	<div class="tumd-main-headself">
		<i class="fa fa-navicon"></i>
	</div>
	<div class="tumd-main-content">
<?php if (!isset($_GET['section']) or $_GET['section'] == "info") { ?>
	<div class="tumd-setting">
		<form class="update-user-info _a-l" method="post">
			<div class="form-header _a-c">
				<span class="_content-title">    
                    <img class="img-20" src="<?=$Tumd['theme_url']?>/image/settings.png"> 
                    <?=$lang['general_config']?>
                </span> 
			</div>
            <span class="_f12 color-grey"><?=$lang['user_username']?></span>
			<div class="tumd-info-input">
				<input type="text" value="<?=$Tumd['data']['username']?>" disabled>
			</div>
            <span class="_f12 color-grey"><?=$lang['name']?></span>
			<div class="tumd-info-input">
				<input type="text" name="name" value="<?=$Tumd['data']['name']?>">
			</div>
            <span class="_f12 color-grey"><?=$lang['email']?></span>
			<div class="tumd-info-input">
				<input type="email" name="email" value="<?=$Tumd['data']['email']?>">
			</div>
            <span class="_f12 color-grey"><?=$lang['user_about']?></span>
			<textarea class="_5vd-t" name="about"><?=$Tumd['info']['about']?></textarea>
			<div class="_a-l">
                <span class="_f12 color-grey"><?=$lang['user_gender']?></span>
				<select name="gender" class="_p4s8">
					<?php
						$gender_1_selected = '';
						$gender_2_selected = '';

						if ($Tumd['info']['gender'] == 1) {
							$gender_1_selected = 'selected';
						} elseif ($Tumd['info']['gender'] == 2) {
							$gender_2_selected = 'selected';
						}
					?>
					<option value="male" <?=$gender_1_selected?>><?=$lang['male']?></option>
					<option value="female" <?=$gender_2_selected?>><?=$lang['female']?></option>
				</select>
			</div>
            <div class="_a-r">
                <button type="submit" class="btn-p btn-p1">
                    <i class="fa fa-check icon-middle"></i>
                    <?=$lang['save']?>
                </button>
            </div>
		</form>
	</div>
<?php } elseif (isset($_GET['section']) && $_GET['section'] == "avatar") { 
	$photo_avatar = getAvatar($Tumd['data']['avatar_id'], $Tumd['info']['gender'], 'medium');
?>
	<div class="tumd-setting _a-r">
		<form class="avatar-form" method="post" enctype="multipart/form-data">
			<div class="avatar-header">
                <span class="_content-title">    
                    <img class="img-20" src="<?=$Tumd['theme_url']?>/image/avatar.png"> 
                    <?=$lang['avatar']?>
                </span>  
            </div>
			<div class="_13n5 tumd-box-load">
				<img class="tumd-loader" src="<?=siteUrl()?>/static/libs/images/ajax-spinner.svg">
				<img class="tumd-avatar" src="<?=$photo_avatar?>">
            </div>
			<input class="avatar-upload-door" type="file" name="image" accept="image/jpeg,image/png">
			<input name="user_id" value="<?=$Tumd['data']['id']?>" type="hidden">
			<button type="submit" id="avatar-btn" class="btn-p btn-p1">
                <i class="fa fa-check icon-middle"></i> 
                <?=$lang['save_image']?>
            </button>
		</form>
	</div>
<?php } elseif (isset($_GET['section']) && $_GET['section'] == "theme") { ?>
    <form class="theme-form" method="post">
        <ul class="_theme-palette _a-c">
            <?php
                $i = 0;
                $sql_query_theme_1 = $Tumdconnect->query("SELECT * FROM ".THEMES."") or die();
                while ($sql_theme_view = mysqli_fetch_array($sql_query_theme_1)) {
                    $i++;
                    $theme_sld = ($Tumd['data']['profile_theme'] == $sql_theme_view['theme_class']) ? 'theme_active':'';
            ?>
            <label>
                <li id="theme-check" data-theme-id="<?=$sql_theme_view['theme_id']?>" class="_theme-viewbox <?=$theme_sld?> theme-chk-<?=$sql_theme_view['theme_id']?>">
                    <div class="_theme-box-item <?=$sql_theme_view['theme_class']?> _a-c">
                        <?=$i?>
                    </div>
                    <?=($Tumd['data']['profile_theme'] == $sql_theme_view['theme_class']) ? 
                    '<input class="hidden" type="radio" name="theme_pilot" value="'.$sql_theme_view['theme_id'].'" checked>' : 
                    '<input class="hidden" type="radio" name="theme_pilot" value="'.$sql_theme_view['theme_id'].'">'?>
                </li>
            </label>
            <?php } ?>
        </ul>
        <div class="_a-r">
            <button class="btn-p btn-p1">
                <i class="fa fa-check icon-middle"></i>
                <?=$lang['save']?> 
            </button>
        </div>
    </form>
<?php } elseif (isset($_GET['section']) && $_GET['section'] == "logs") { ?>
	<div class="col-lg-12 general-box">
		<div class="_logHeader _a-c _content-title">
        <img class="img-20" src="<?=$Tumd['theme_url']?>/image/flag.png">
            <?=$lang['activity_register']?> 
			<img id="logs-loader" src="<?=siteUrl()?>/static/libs/images/ajax-spinner.svg">
		</div>
        <div id="tumd-logs-content" class="_selfimg-log"></div>
        <div class="_a-c"><a href="#" id="logs-viewmore" class="_logview-more-btn"><?=$lang['view_more']?></a></div>
	</div>
<?php } elseif (isset($_GET['section']) && $_GET['section'] == "password") { ?>
    <div class="tumd-setting _a-r">
        <form class="update-user-password" method="post">
            <div class="form-header">
                <span class="_content-title">    
                    <img class="img-20" src="<?=$Tumd['theme_url']?>/image/password.png"> 
                    <?=$lang['change_password']?>
                </span> 
            </div>

            <div class="tumd-info-input">
                <input type="password" name="current_password" placeholder="<?=$lang['current_password']?>">
            </div>
            <div class="tumd-info-input">
                <input type="password" name="new_password" placeholder="<?=$lang['new_password']?>">
            </div>
            <div class="tumd-info-input">
                <input type="password" name="new_password_v" placeholder="<?=$lang['repeat_new_password']?>">
            </div>

            <button type="submit" class="btn-p btn-p1">
                <i class="fa fa-check icon-middle"></i>
                <?=$lang['change']?>
            </button>
        </form>
    </div>
<?php } else { echo incPage('welcome/error-section'); } ?>
	</div>
</div>

<div class="tumd-nav pull-left span20">
    <div class="tumd-nav-headself"><?=$lang['configuration']?></div>
    <?=incPage('user/nav-menu')?>
</div>
</div>
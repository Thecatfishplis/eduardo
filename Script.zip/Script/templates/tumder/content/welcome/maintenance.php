<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=$Tumd['config']['setting']['site_name']?> &rsaquo; <?=$lang['maintenance_on']?></title>
	<meta name="description" content="<?=$Tumd['config']['setting']['site_description']?>">
    <meta name="keywords" content="<?=$Tumd['config']['setting']['site_keywords']?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" type="text/css" href="<?php echo $Tumd['theme_url'];?>/css/font/roboto/roboto-style.css">
	<style type="text/css">
		* {
			color: #FFF;
			text-shadow: 0px 2px 2px rgba(0, 0, 0, 0.9);
		}
		body {
			font-family: 'roboto-light';
			background: url('<?=$Tumd['theme_url']?>/image/src/games-poster.png');
			padding: 0;
			margin: 0;
		}
		h1 {
			margin: 3px 0;
		}
		._3zWll {
			background: -webkit-linear-gradient(rgba(72, 83, 101, 0.62), rgba(53, 71, 97, 0.89));
			background: -o-linear-gradient(rgba(72, 83, 101, 0.62), rgba(53, 71, 97, 0.89));
			background: linear-gradient(rgba(72, 83, 101, 0.62), rgba(53, 71, 97, 0.89));
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
		}
		._box-Qt1 {
			width: 500px;
			margin: 10% auto;
		}
		._-x35pA {
			text-align: center;
		}
		._3dFr9 {
			text-align: justify;
			font-size: 25px;
		}
	</style>
</head>
<body>
	<div class="_3zWll">
		<div class="_box-Qt1">
			<div class="_-x35pA">
				<img src="<?=$Tumd['theme_url']?>/image/icon-color/worker_male.png">
			</div>
			<h1 class="_-x35pA"><?=$lang['maintenance_on']?></h1>
			<div class="_3dFr9"><?=$Tumd['config']['setting']['maintenance_msg']?></div>
		</div>
	</div>
</body>
</html>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<div class="tumd-main span100">
<?php if (!isset($_GET['utm_securelogin'])) { ?>
	<div class="tumd-door">
		<div class="door-circle-itr">
			<img src="<?=$Tumd['theme_url']?>/image/icon-color/login.png">
		</div>
		<div class="tumd-door-container">
			<form class="signin-form" method="post">
				<div class="form-header"><?=$lang['header_login']?></div>

				<div class="vByg5">
					<input type="text" name="login_id" placeholder="<?=$lang['user_email']?>">
				</div>
				<div class="vByg5">
					<input type="password" name="login_key" placeholder="<?=$lang['password']?>">
				</div>
				<?php if(isset($_GET['redirect_url']) && !empty($_GET['redirect_url'])) { ?>
				<input name="redirect_url" value="<?=$_GET['redirect_url']?>" type="hidden">
				<?php } ?>
				<div class="_yt10 _a-r">
					<a href="<?=siteUrl()?>/login/secure"><?=$lang['login_message_1']?></a>
					<input class="submit-btn _index-btn" type="submit" value="<?=$lang['sign_in']?>">
				</div>
			</form>
		</div>
	</div>
<?php } elseif (isset($_GET['utm_securelogin']) or $_GET['utm_securelogin'] == 1) { ?>
	<div class="tumd-door">
		<div class="door-circle-itr">
			<img src="<?=$Tumd['theme_url']?>/image/icon-color/ssid.png">
		</div>
		<div class="tumd-door-container">
			<form class="securelogin-form" method="post">
				<div class="form-header"><?=$lang['secure_login']?></div>
				<div class="vByg5">
					<input type="text" name="secure_secret_user" placeholder="<?=$lang['user']?>">
				</div>
				<div class="vByg5">
					<input type="password" name="secure_secret_id" placeholder="<?=$lang['secure_id']?>">
				</div>
				<div class="_yt10 _a-r">
					<a href="<?=siteUrl()?>/login"><?=$lang['login_message_2']?></a>
					<input class="submit-btn _index-btn" type="submit" value="<?=$lang['sign_in']?>">
				</div>
			</form>
		</div>
	</div>
<?php } ?>
</div>
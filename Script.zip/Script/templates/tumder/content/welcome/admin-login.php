<?php if ( defined("ADMIN_ACCESS") != true ) { die(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=$lang['page_admin']?> &rsaquo; <?=$lang['page_login']?></title>
	<link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/font/roboto/roboto-style.css">
	<link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/admin/36mqcX5bF3-login.css">
	 <script type="text/javascript" src="<?=$Tumd['config']['setting']['site_url']?>/static/libs/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?=$Tumd['config']['setting']['site_url']?>/static/libs/js/jquery.form.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/libs/toast.css">
	<script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/libs/toast.min.js"></script>
	<script type="text/javascript" src="<?=$Tumd['config']['setting']['site_url']?>/static/libs/js/root.js"></script>
	<script type="text/javascript">
		var siteUrl = '<?=siteUrl()?>';
	</script>
	<script type="text/javascript">
    $('#admin-access-form').ajaxForm({
        url: Ajaxrequest() + '?t=admin-login',
        type: 'POST',
        success: function(data) {
            if (data.status == 200) {
                window.location = data.redirect_url;
            } else {
                Toast.error(data.error_message);
            }
        }
    });
	</script>
</head>
<body>
	<div class="_sW3ot">
		<div class="_sL">
			<img src="<?=siteUrl()?>/static/logo/td-logo.png">
		</div>
		<form class="_f" id="admin-access-form" method="POST">
			<input class="_CsI8" type="text" name="login_id" placeholder="<?=$lang['user']?>">
			<input class="_CsI8 _s3C" type="password" name="login_key" placeholder="<?=$lang['password']?>">
			<input class="_CsI8" type="password" name="admin_pin" placeholder="<?=$lang['admin_pin']?>">
			<button class="_vR8u" type="submit"><?=$lang['sign_in']?></button>
		</form>
	</div>
</body>
</html>
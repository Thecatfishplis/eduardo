<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>

<div class="tumd-door">
	<div class="door-circle-itr">
		<img src="<?=$Tumd['theme_url']?>/image/icon-color/sign_up.png">
	</div>
	<div class="tumd-door-container">
		<form class="signup-form" method="post">
			<div class="form-header"><?=$lang['sign_up']?></div>
			<div class="vByg5">
				<input type="email" name="email" placeholder="<?=$lang['email']?>">
			</div>
			<div class="vByg5">
				<input type="text" name="name" placeholder="<?=$lang['name']?>">
			</div>
			<div class="vByg5">
				<input type="text" name="username" placeholder="<?=$lang['user']?>">
			</div>
			<div class="vByg5">
				<input type="password" name="password" placeholder="<?=$lang['password']?>">
			</div>

			<div class="_a-c"><?=$lang['secure_id']?></div>
			<div class="vByg5">
				<input type="password" name="secret_sid" placeholder="<?=$lang['ssid']?>">
			</div>
			<div class="vByg5">
				<input type="password" name="vsecret_sid" placeholder="<?=$lang['repeat_ssid']?>">
			</div>

			<input class="submit-btn _index-btn pull-right" type="submit" value="<?=$lang['sign_up']?>">
		</form>
	</div>
</div>
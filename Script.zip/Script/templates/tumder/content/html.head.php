<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
    <meta charset="UTF-8">
    <?=title_tag()?>
    <meta name="description" content="<?=$Tumd['config']['setting']['site_description']?>">
    <meta name="keywords" content="<?=$Tumd['config']['setting']['site_keywords']?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <?php if ($_GET['p'] == 'play' && !empty($_GET['id']) && getGame($_GET['id']) == true) {
        $game_data = getGame($_GET['id']);
        $game_info = gameData($game_data);
    ?>
    <meta property="og:title" content="<?=$game_info['name']?>"/>
    <meta property="og:type" content="game"/>
    <meta property="og:url" content="<?=$game_info['game_url']?>"/>
    <meta property="og:image" content="<?=$game_info['image_url']?>"/>
    <meta property="og:site_name" content="<?=$Tumd['config']['setting']['site_name']?>"/>
    <meta property="og:description" content="<?=$game_info['description']?>"/>
    <meta name="twitter:title" content="<?=$game_info['name']?>">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="<?=$game_info['game_url']?>">
    <meta name="twitter:image" content="<?=$game_info['image_url']?>">
    <meta name="twitter:description" content="<?=$game_info['description']?>">
    <?php } ?>
    
    <!--* Stylesheets *-->
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/98cb1q8d53p-1.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/98cb1q8d53p-responsive.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/font/roboto/roboto-style.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/98cb1q8d53p-style.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/libs/owl/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/libs/owl/owl.theme.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/libs/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/libs/toast.css">
    <link rel="icon" type="image/x-icon" href="<?=siteUrl()?>/favicon.ico">

    <!--* Javascripts *-->
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/spf/2.4.0/spf.js"></script>
    <script type="text/javascript">spf.init();</script>
    <script type="text/javascript" src="<?=siteUrl()?>/static/libs/js/jquery.min.js"></script>

    <?php if($Tumd['access'] == true && $Tumd['data']['admin'] == true){?>
    <link rel="stylesheet" type="text/css" href="<?=$Tumd['theme_url']?>/css/admin/36mqcX5bF3-1.css">
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/admin/engine-admin.js"></script>
    <?php } ?>

    <!--[if lt IE 9]>
    <script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
        var siteUrl = '<?=siteUrl()?>';
    </script>
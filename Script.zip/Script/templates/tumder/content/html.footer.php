<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } ?>
    
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/libs/owl/owl.carousel.min.js"></script>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/libs/sweetalert.min.js"></script>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/libs/bigscreen.min.js"></script>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/libs/toast.min.js"></script>
    <script type="text/javascript" src="<?=siteUrl()?>/static/libs/js/jquery.form.min.js"></script>
    <script type="text/javascript" src="<?=siteUrl()?>/static/libs/js/root.js"></script>
    <?php if($Tumd['access'] == true){ ?>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/engine.js"></script>
    <?php } else { ?>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/index.js"></script>
    <?php } ?>
    <script type="text/javascript" src="<?=$Tumd['theme_url']?>/js/general.js"></script>
    <?php if ($_GET['p'] == 'play' && !empty($_GET['id']) && getGame($_GET['id']) == true) { ?>
    <script type="text/javascript">
        var __AdNum = <?=$Tumd['config']['setting']['ad_time']?> + 1,
            __g_net = <?=$Tumd['game']['id']?>;
        window.setTimeout(function(){__upGame_rx8(__g_net)}, 15000);
        window.setTimeout(function(){__upGame_rx9()}, 800000);
        
        <?php if($Tumd['config']['setting']['ads_status'] == 1) { ?>
        __AdRemoveCount();
        __adCountD();
        <?php } ?>
    </script>
    <?php } ?>
<?php if ( defined("PILOT_GLOBAL") != true ) { die(); } 
	$photo_avatar = getAvatar($Tumd['profile']['data']['avatar_id'], $Tumd['profile']['info']['gender'], 'medium');
	$gender = ($Tumd['profile']['info']['gender'] == 1) ? '<img class="img-20" src="'.$Tumd['theme_url'].'/image/icon-color/male.png"> '.$lang['male'] : '<img class="img-20" src="'.$Tumd['theme_url'].'/image/icon-color/female.png"> '.$lang['female'] ;
?>

<div class="tumd-main span100">
	<div class="tumd-profile">
		<div class="_profile-cover <?=$Tumd['profile']['data']['profile_theme']?>">
			<div class="_profile-image _a-c">
				<img src="<?=$photo_avatar?>" class="_profile-picture">
			</div>
			<div class="_profile-name _a-c">
				<span><?=$Tumd['profile']['data']['name']?></span>
			</div>
		</div>
		<div class="_profile-box-info _b-r _b-l">
			<div title="<?=$lang['last_login']?>" class="_bv3-9 _dr5-w">
				<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/login.png"> 
				<?=dateState($Tumd['profile']['data']['last_logged'])?>
			</div>
			<div title="<?=$lang['xp_points']?>" class="_bv3-9 _bc5-3 _vf5-4 _dr5-w">
				<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/star_xp.png"> 
				<?=numberFormat($Tumd['profile']['data']['xp'])?>
			</div>
			<div title="<?=$lang['last_update_info']?>" class="_bv3-9 _dr5-w">
				<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/update-info.png"> 
				<?=dateState($Tumd['profile']['data']['last_update_info'], 5)?>
			</div>
		</div>
		<div class="_profile-box-more _yt5">
			<div class="_d63-8 _5e4 _b-r _a-c">
				<span class="_content-title"><img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/plays.png"> <?=$lang['new_games_visited']?></span>
			<?php
				$sql_query_played = $Tumdconnect->query("SELECT DISTINCT game_id FROM ".USER_GAME." WHERE user_id = '{$Tumd['profile']['data']['id']}' AND type='played' AND game_id!='0' ORDER BY date_added DESC LIMIT 6");
				while ($sql_played_row = mysqli_fetch_array($sql_query_played)) {

					$sql_query_gameplayed = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE game_id = '{$sql_played_row['game_id']}' AND published = '1'");
					while($sql_gameplayed_row = mysqli_fetch_array($sql_query_gameplayed)){
						$user_played = gameData($sql_gameplayed_row);
			?>	
				<div style="background: url('<?=$user_played['image_url']?>') no-repeat;" class="game-app-data" title="<?=$user_played['name']?>">
					<a href="<?=$user_played['game_url']?>"></a>
				</div>
			<?php } } 
				if ($sql_query_played->num_rows == 0) {
					echo '<div class="_tr5 alert alert-ss info">'. $Tumd['profile']['data']['name'].' '.$lang['user_not_played'].'</div>';
				}
			?>
			</div>
			<div class="_d63-8">
				<div class="_5e4 _b-b">
					<?=$gender?>
				</div>
				<div class="_5e4">
					<img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/pencil.png">
					<?=(!empty($Tumd['profile']['info']['about'])) ? $Tumd['profile']['info']['about'] : $Tumd['profile']['data']['name'].' '.$lang['not_description'].'...';?>
				</div>
			</div>
		</div>
		<?=$Tumd['ads']['header']?>
		<div class="general-box _yt5 _yb10">
			<span class="_content-title"><img class="img-20" src="<?=$Tumd['theme_url']?>/image/icon-color/star.png"> <?=$lang['my_favorite_games']?></span>
			<ul class="card">
			<?php
				$sql_query_fav = $Tumdconnect->query("SELECT game_id FROM ".USER_GAME." WHERE user_id = '{$Tumd['profile']['data']['id']}' AND type='favorite' AND game_id!='0'");
				while ($sql_user_row = mysqli_fetch_array($sql_query_fav)) {

					$sql_query_game = $Tumdconnect->query("SELECT * FROM ".GAMES." WHERE game_id = '{$sql_user_row['game_id']}' AND published = '1'");
					while($sql_game_row = mysqli_fetch_array($sql_query_game)){
					$user_fav = gameData($sql_game_row);
			?>
			<li class="card-item">
				<figure class="card-game">
					<?php if($sql_game_row['featured'] == true) { ?>
					<span class="card-icon-corner"></span>
					<i class="fa fa-heart icon-18 icon-corner"></i>
					<?php } ?>
					<a class="g-media" data-href="<?=$user_fav['game_url']?>" href="<?=$user_fav['game_url']?>">
						<img src="<?=$user_fav['image_url']?>" width="140px" height="96px">
						<span class="name ellipsis"><?=$user_fav['name']?></span>
					</a>
					<span class="cb-pro"></span>
				</figure>
			</li>
		<?php } } ?>
			</ul>
		<?php if ($sql_query_fav->num_rows == 0) {
			echo '<div class="_tr5 alert alert-ss info">'. $Tumd['profile']['data']['name'].' '.$lang['user_not_favorite'].'</div>';
		}
		?>
		</div>
	</div>
</div>